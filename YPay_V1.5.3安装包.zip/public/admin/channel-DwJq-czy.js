const e={id:"id",weigh:"weigh","quick Search Fields":"id"};export{e as default};
