import{d as r}from"./index-B_o2lbln.js";const o="/admin/user.MoneyLog/";function t(a){return r({url:o+"add",method:"get",params:{userId:a}})}export{t as a,o as u};
