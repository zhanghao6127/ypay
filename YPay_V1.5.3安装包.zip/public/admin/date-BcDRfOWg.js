const t={id:"id",timestamp:"timestamp","quick Search Fields":"id"};export{t as default};
