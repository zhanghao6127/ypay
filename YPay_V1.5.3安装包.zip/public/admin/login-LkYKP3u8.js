const e={"Please enter an account":"Please enter your account","Please input a password":"Please enter your password","Hold session":"Keep the session","Sign in":"Sign in"};export{e as default};
