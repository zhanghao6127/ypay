import{d as a}from"./index-B_o2lbln.js";const o="/admin/user.ScoreLog/";function t(r){return a({url:o+"add",method:"get",params:{userId:r}})}export{t as a,o as u};
