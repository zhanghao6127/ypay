import{d as e}from"./index-B_o2lbln.js";function t(){return e({url:"/admin/user.Rule/index",method:"get"})}export{t as g};
