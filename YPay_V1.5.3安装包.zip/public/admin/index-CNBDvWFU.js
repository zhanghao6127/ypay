const e={"Steve Jobs":"Great art don't have to follow the trend, it alone can lead.-- Steve Jobs"};export{e as default};
