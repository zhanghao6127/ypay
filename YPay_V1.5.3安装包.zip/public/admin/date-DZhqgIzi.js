const e={id:"ID",timestamp:"时间日期","quick Search Fields":"ID"};export{e as default};
