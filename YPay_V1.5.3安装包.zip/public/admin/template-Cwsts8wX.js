const t={id:"ID",name:"名称",content:"内容",status:"状态","status 0":"禁用","status 1":"启用",remark:"备注",update_time:"修改时间",create_time:"创建时间","quick Search Fields":"ID"};export{t as default};
