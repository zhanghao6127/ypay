const e={id:"ID",weigh:"权重","quick Search Fields":"ID"};export{e as default};
