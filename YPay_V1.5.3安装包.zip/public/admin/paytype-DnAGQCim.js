const t={id:"ID",name:"类型名称",type:"类型code",status:"状态","status 0":"禁用","status 1":"启用",create_time:"创建时间",update_time:"修改时间","quick Search Fields":"ID"};export{t as default};
