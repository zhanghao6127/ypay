/* empty css              */import{c as r}from"./VAvatar-CD_55bcM.js";const e=r("v-spacer","div","VSpacer");export{e as V};
