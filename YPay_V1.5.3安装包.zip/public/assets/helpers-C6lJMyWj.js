const r=n=>n==null,e=n=>Array.isArray(n)&&n.length===0;export{e as a,r as i};
