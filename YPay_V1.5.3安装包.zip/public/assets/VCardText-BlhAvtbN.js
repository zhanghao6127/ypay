import{c as t}from"./VAvatar-CD_55bcM.js";const e=t("v-card-text");export{e as V};
