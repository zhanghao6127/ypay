const a="/assets/avatar-1-DMk2FF1-.png";export{a};
