const e=r=>r?r.split(" ").map(a=>a.charAt(0).toUpperCase()).join(""):"";export{e as a};
