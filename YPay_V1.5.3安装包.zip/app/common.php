<?php
// 应用公共文件

use app\admin\model\mail\Template;
use app\common\library\Email;
use GuzzleHttp\HandlerStack;
use PHPMailer\PHPMailer\Exception as PHPMailerException;
use think\App;
use ba\Filesystem;
use think\facade\Cache;
use think\facade\Queue;
use think\Response;
use think\facade\Db;
use think\facade\Lang;
use think\facade\Event;
use think\facade\Config;
use voku\helper\AntiXSS;
use app\admin\model\Config as configModel;
use think\exception\HttpResponseException;
use Symfony\Component\HttpFoundation\IpUtils;

if (!function_exists('__')) {

    /**
     * 语言翻译
     * @param string $name 被翻译字符
     * @param array  $vars 替换字符数组
     * @param string $lang 翻译语言
     * @return mixed
     */
    function __(string $name, array $vars = [], string $lang = ''): mixed
    {
        if (is_numeric($name) || !$name) {
            return $name;
        }
        return Lang::get($name, $vars, $lang);
    }
}

if (!function_exists('filter')) {

    /**
     * 输入过滤
     * 富文本反XSS请使用 clean_xss，也就不需要及不能再 filter 了
     * @param string $string 要过滤的字符串
     * @return string
     */
    function filter(string $string): string
    {
        // 去除字符串两端空格（对防代码注入有一定作用）
        $string = trim($string);

        // 过滤html和php标签
        $string = strip_tags($string);

        // 特殊字符转实体
        return htmlspecialchars($string, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401, 'UTF-8');
    }
}

if (!function_exists('clean_xss')) {

    /**
     * 清理XSS
     * 通常只用于富文本，比 filter 慢
     * @param string $string
     * @return string
     */
    function clean_xss(string $string): string
    {
        return (new AntiXSS())->xss_clean($string);
    }
}

if (!function_exists('htmlspecialchars_decode_improve')) {
    /**
     * html解码增强
     * 被 filter函数 内的 htmlspecialchars 编码的字符串，需要用此函数才能完全解码
     * @param string $string
     * @param int    $flags
     * @return string
     */
    function htmlspecialchars_decode_improve(string $string, int $flags = ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401): string
    {
        return htmlspecialchars_decode($string, $flags);
    }
}

if (!function_exists('get_sys_config')) {

    /**
     * 获取站点的系统配置，不传递参数则获取所有配置项
     * @param string $name    变量名
     * @param string $group   变量分组，传递此参数来获取某个分组的所有配置项
     * @param bool   $concise 是否开启简洁模式，简洁模式下，获取多项配置时只返回配置的键值对
     * @return mixed
     * @throws Throwable
     */
    function get_sys_config(string $name = '', string $group = '', bool $concise = true): mixed
    {
        if ($name) {
            // 直接使用->value('value')不能使用到模型的类型格式化
            $config = configModel::where('name', $name)->find();
            if ($config) $config = $config['value'];
        } else {
            if ($group) {
                $temp = configModel::where('group', $group)->select()->toArray();
            } else {
                $temp = configModel::cache('sys_config_all', null, configModel::$cacheTag)->order('weigh desc')->select()->toArray();
            }
            if ($concise) {
                $config = [];
                foreach ($temp as $item) {
                    $config[$item['name']] = $item['value'];
                }
            } else {
                $config = $temp;
            }
        }
        return $config;
    }
}

if (!function_exists('get_route_remark')) {

    /**
     * 获取当前路由后台菜单规则的备注信息
     * @return string
     */
    function get_route_remark(): string
    {
        $controllerName = request()->controller(true);
        $actionName     = request()->action(true);
        $path           = str_replace('.', '/', $controllerName);

        $remark = Db::name('admin_rule')
            ->where('name', $path)
            ->whereOr('name', $path . '/' . $actionName)
            ->value('remark');
        return __((string)$remark);
    }
}

if (!function_exists('full_url')) {

    /**
     * 获取资源完整url地址；若安装了云存储或 config/buildadmin.php 配置了CdnUrl，则自动使用对应的CdnUrl
     * @param string  $relativeUrl 资源相对地址 不传入则获取域名
     * @param boolean $domain      是否携带域名 或者直接传入域名
     * @param string  $default     默认值
     * @return string
     */
    function full_url(string $relativeUrl = '', bool $domain = true, string $default = ''): string
    {
        // 存储/上传资料配置
        Event::trigger('uploadConfigInit', App::getInstance());

        $cdnUrl = Config::get('buildadmin.cdn_url');
        if (!$cdnUrl) $cdnUrl = request()->upload['cdn'] ?? request()->domain();
        if ($domain === true) {
            $domain = $cdnUrl;
        } elseif ($domain === false) {
            $domain = '';
        }

        $relativeUrl = $relativeUrl ?: $default;
        if (!$relativeUrl) return $domain;

        $regex = "/^((?:[a-z]+:)?\/\/|data:image\/)(.*)/i";
        if (preg_match('/^http(s)?:\/\//', $relativeUrl) || preg_match($regex, $relativeUrl) || $domain === false) {
            return $relativeUrl;
        }
        return $domain . $relativeUrl;
    }
}

if (!function_exists('encrypt_password')) {

    /**
     * 加密密码
     */
    function encrypt_password($password, $salt = '', $encrypt = 'md5')
    {
        return $encrypt($encrypt($password) . $salt);
    }
}

if (!function_exists('str_attr_to_array')) {

    /**
     * 将字符串属性列表转为数组
     * @param string $attr 属性，一行一个，无需引号，比如：class=input-class
     * @return array
     */
    function str_attr_to_array(string $attr): array
    {
        if (!$attr) return [];
        $attr     = explode("\n", trim(str_replace("\r\n", "\n", $attr)));
        $attrTemp = [];
        foreach ($attr as $item) {
            $item = explode('=', $item);
            if (isset($item[0]) && isset($item[1])) {
                $attrVal = $item[1];
                if ($item[1] === 'false' || $item[1] === 'true') {
                    $attrVal = !($item[1] === 'false');
                } elseif (is_numeric($item[1])) {
                    $attrVal = (float)$item[1];
                }
                if (strpos($item[0], '.')) {
                    $attrKey = explode('.', $item[0]);
                    if (isset($attrKey[0]) && isset($attrKey[1])) {
                        $attrTemp[$attrKey[0]][$attrKey[1]] = $attrVal;
                        continue;
                    }
                }
                $attrTemp[$item[0]] = $attrVal;
            }
        }
        return $attrTemp;
    }
}

if (!function_exists('action_in_arr')) {

    /**
     * 检测一个方法是否在传递的数组内
     * @param array $arr
     * @return bool
     */
    function action_in_arr(array $arr = []): bool
    {
        $arr = is_array($arr) ? $arr : explode(',', $arr);
        if (!$arr) {
            return false;
        }
        $arr = array_map('strtolower', $arr);
        if (in_array(strtolower(request()->action()), $arr) || in_array('*', $arr)) {
            return true;
        }
        return false;
    }
}

if (!function_exists('build_suffix_svg')) {

    /**
     * 构建文件后缀的svg图片
     * @param string  $suffix     文件后缀
     * @param ?string $background 背景颜色，如：rgb(255,255,255)
     * @return string
     */
    function build_suffix_svg(string $suffix = 'file', string $background = null): string
    {
        $suffix = mb_substr(strtoupper($suffix), 0, 4);
        $total  = unpack('L', hash('adler32', $suffix, true))[1];
        $hue    = $total % 360;
        [$r, $g, $b] = hsv2rgb($hue / 360, 0.3, 0.9);

        $background = $background ?: "rgb($r,$g,$b)";

        return '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
            <path style="fill:#E2E5E7;" d="M128,0c-17.6,0-32,14.4-32,32v448c0,17.6,14.4,32,32,32h320c17.6,0,32-14.4,32-32V128L352,0H128z"/>
            <path style="fill:#B0B7BD;" d="M384,128h96L352,0v96C352,113.6,366.4,128,384,128z"/>
            <polygon style="fill:#CAD1D8;" points="480,224 384,128 480,128 "/>
            <path style="fill:' . $background . ';" d="M416,416c0,8.8-7.2,16-16,16H48c-8.8,0-16-7.2-16-16V256c0-8.8,7.2-16,16-16h352c8.8,0,16,7.2,16,16 V416z"/>
            <path style="fill:#CAD1D8;" d="M400,432H96v16h304c8.8,0,16-7.2,16-16v-16C416,424.8,408.8,432,400,432z"/>
            <g><text><tspan x="220" y="380" font-size="124" font-family="Verdana, Helvetica, Arial, sans-serif" fill="white" text-anchor="middle">' . $suffix . '</tspan></text></g>
        </svg>';
    }
}

if (!function_exists('get_area')) {

    /**
     * 获取省份地区数据
     * @throws Throwable
     */
    function get_area(): array
    {
        $province = request()->get('province', '');
        $city     = request()->get('city', '');
        $where    = ['pid' => 0, 'level' => 1];
        if ($province !== '') {
            $where['pid']   = $province;
            $where['level'] = 2;
            if ($city !== '') {
                $where['pid']   = $city;
                $where['level'] = 3;
            }
        }
        return Db::name('area')
            ->where($where)
            ->field('id as value,name as label')
            ->select()
            ->toArray();
    }
}

if (!function_exists('hsv2rgb')) {
    function hsv2rgb($h, $s, $v): array
    {
        $r = $g = $b = 0;

        $i = floor($h * 6);
        $f = $h * 6 - $i;
        $p = $v * (1 - $s);
        $q = $v * (1 - $f * $s);
        $t = $v * (1 - (1 - $f) * $s);

        switch ($i % 6) {
            case 0:
                $r = $v;
                $g = $t;
                $b = $p;
                break;
            case 1:
                $r = $q;
                $g = $v;
                $b = $p;
                break;
            case 2:
                $r = $p;
                $g = $v;
                $b = $t;
                break;
            case 3:
                $r = $p;
                $g = $q;
                $b = $v;
                break;
            case 4:
                $r = $t;
                $g = $p;
                $b = $v;
                break;
            case 5:
                $r = $v;
                $g = $p;
                $b = $q;
                break;
        }

        return [
            floor($r * 255),
            floor($g * 255),
            floor($b * 255)
        ];
    }
}

if (!function_exists('ip_check')) {

    /**
     * IP检查
     * @throws Throwable
     */
    function ip_check($ip = null): void
    {
        $ip       = is_null($ip) ? request()->ip() : $ip;
        $noAccess = get_sys_config('no_access_ip');
        $noAccess = !$noAccess ? [] : array_filter(explode("\n", str_replace("\r\n", "\n", $noAccess)));
        if ($noAccess && IpUtils::checkIp($ip, $noAccess)) {
            $response = Response::create(['msg' => 'No permission request'], 'json', 403);
            throw new HttpResponseException($response);
        }
    }
}

if (!function_exists('set_timezone')) {

    /**
     * 设置时区
     * @throws Throwable
     */
    function set_timezone($timezone = null): void
    {
        $defaultTimezone = Config::get('app.default_timezone');
        $timezone        = is_null($timezone) ? get_sys_config('time_zone') : $timezone;
        if ($timezone && $defaultTimezone != $timezone) {
            Config::set([
                'app.default_timezone' => $timezone
            ]);
            date_default_timezone_set($timezone);
        }
    }
}

if (!function_exists('get_upload_config')) {

    /**
     * 获取上传配置
     * @return array
     */
    function get_upload_config(): array
    {
        // 存储/上传资料配置
        Event::trigger('uploadConfigInit', App::getInstance());

        $uploadConfig            = Config::get('upload');
        $uploadConfig['maxsize'] = Filesystem::fileUnitToByte($uploadConfig['maxsize']);

        $upload = request()->upload;
        if (!$upload) {
            $uploadConfig['mode'] = 'local';
            return $uploadConfig;
        }
        unset($upload['cdn']);
        return array_merge($upload, $uploadConfig);
    }
}

if (!function_exists('downFile')) {
    function downFile($url, $path)
    {
        $arr      = parse_url($url);
        $fileName = basename($arr['path']);

        $stream_opts = [
            "ssl" => [
                "verify_peer"      => false,
                "verify_peer_name" => false,
            ]
        ];
        $file        = file_get_contents($url, false, stream_context_create($stream_opts));
        file_put_contents($path . $fileName, $file);
        return $fileName;
    }
}

if (!function_exists('delDir')) {
    function delDir($directory)
    {
        if (file_exists($directory)) {//判断目录是否存在，如果不存在rmdir()函数会出错
            if ($dir_handle = @opendir($directory)) {//打开目录返回目录资源，并判断是否成功
                while ($filename = readdir($dir_handle)) {//遍历目录，读出目录中的文件或文件夹
                    if ($filename != '.' && $filename != '..') {//一定要排除两个特殊的目录
                        $subFile = $directory . "/" . $filename;//将目录下的文件与当前目录相连
                        if (is_dir($subFile)) {//如果是目录条件则成了
                            delDir($subFile);//递归调用自己删除子目录
                        }
                        if (is_file($subFile)) {//如果是文件条件则成立
                            unlink($subFile);//直接删除这个文件
                        }
                    }
                }
                closedir($dir_handle);//关闭目录资源
                rmdir($directory);//删除空目录
            }
        }
    }
}

if (!function_exists('copyDirectory')) {
    function copyDirectory($source, $destination)
    {
        if (!is_dir($destination)) {
            mkdir($destination, 0755, true);
        }
        $files = scandir($source);
        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..') {
                $sourceFile      = $source . '/' . $file;
                $destinationFile = $destination . '/' . $file;
                if (is_dir($sourceFile)) {
                    copyDirectory($sourceFile, $destinationFile);
                } else {
                    copy($sourceFile, $destinationFile);
                }
            }
        }
    }
}

if (!function_exists('rand_string')) {
    /**
     *  随机数
     *
     * @param string $length 长度
     * @param string $type   类型
     * @return void
     */
    function rand_string($length = '32', $type = 4): string
    {
        $rand = '';
        switch ($type) {
            case '1':
                $randstr = '0123456789';
                break;
            case '2':
                $randstr = 'abcdefghijklmnopqrstuvwxyz';
                break;
            case '3':
                $randstr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                break;
            default:
                $randstr = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                break;
        }
        $max = strlen($randstr) - 1;
//        mt_srand((int)microtime() * 1000000);
        for ($i = 0; $i < $length; $i++) {
            $rand .= $randstr[mt_rand(0, $max)];
        }
        return $rand;
    }
}

if (!function_exists('domain')) {
    function domain()
    {
        return request()->domain();
    }
}
if (!function_exists('getSubstr')) {
    function getSubstr($str, $leftStr, $rightStr)
    {
        $left  = strpos($str, $leftStr);
        $right = strpos($str, $rightStr, $left);
        if ($left < 0 or $right < $left) return '';
        return substr($str, $left + strlen($leftStr), $right - $left - strlen($leftStr));
    }
}

if (!function_exists('get_curl')) {
    function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0, $split = 0)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        $httpheader[] = "Accept:*/*";
        $httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
        $httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
        $httpheader[] = "Connection:close";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HEADER, TRUE);
        }
        if ($cookie) {
            curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        }
        if ($referer) {
            curl_setopt($ch, CURLOPT_REFERER, $referer);
        }
        if ($ua) {
            curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        } else {
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36');
        }
        if ($nobaody) {
            curl_setopt($ch, CURLOPT_NOBODY, 1);

        }
        curl_setopt($ch, CURLOPT_ENCODING, "gzip");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        $ret = curl_exec($ch);
        if ($split) {
            $headerSize    = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $header        = substr($ret, 0, $headerSize);
            $body          = substr($ret, $headerSize);
            $ret           = array();
            $ret['header'] = $header;
            $ret['body']   = $body;
        }
        if (curl_getinfo($ch, CURLINFO_HTTP_CODE) == 404) {
            $ret = false;
        }
        curl_close($ch);
        return $ret;
    }
}

if (!function_exists('getCallBack')) {
    function getCallBack($url)
    {
        try {
            $res = guzzle_client_get($url);

            if (empty($res) || $res != 'success') {
                return 'error';
            }
            return 'success';
        } catch (Exception $e) {
            return 'error';
        }
    }
}

if (!function_exists('guzzle_client_get_by_cookie')){
    function guzzle_client_get_by_cookie($url, $header = [], $cookies = "",$needHeader = false)
    {
        $urlInfo = parse_url($url);
        if (!empty($urlInfo['scheme']) && $urlInfo['scheme'] == 'https') {
            $port = 443;
            $is_https = true;
            $url = "https://{$urlInfo['host']}{$urlInfo['path']}";
        } else {
            // 如果URL没有指定端口，或者协议不是https，则默认为80
            $port = isset($urlInfo['port']) ? $urlInfo['port'] : 80;
            $is_https = false;
            $url = "http://{$urlInfo['host']}{$urlInfo['path']}";
        }


        $client = new \Swoole\Coroutine\Http\Client($urlInfo['host'],$port,$is_https);
        $client->set(['timeout' => 30]);

        if (!$header) {
            $header = [
                'Referer' =>'https://shanghu.alipay.com/user/myAccount/index.htm',
                'User-Agent'      => 'Mozilla/5.0 (Linux; Android 10.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36 360Browser/9.2.5584.400"'
            ];
        }
        $client->setHeaders($header);
        if (!empty($cookies)){
            $cookies = explode(';',$cookies);
            if (!empty($cookies)){
                $new_ck = [];
                foreach ($cookies as $v){
                    $v = trim($v);
                    $v = explode('=',$v);
                    if (isset($v[0])&& isset($v[1])){
                        $new_ck[$v[0]] = $v[1];
                    }
                }
                $client->setCookies($new_ck);
            }
        }
        $client->get($url);

        if (!$needHeader){
            return $client->body;
        }else{
            return [
                'header' => $client->headers,
                'body'   => $client->body
            ];
        }



        return $res->getBody()->getContents();
    }
}

if (!function_exists('guzzle_client_get')) {
    function guzzle_client_get($url, $header = [], $cookies = "")
    {
        $client = new \GuzzleHttp\Client(['http_errors' => false]);
        if (!$header) {
            $header = [
                'Accept'          => '*',
                'Accept-Encoding' => 'gzip,deflate,sdch',
                'Accept-Language' => 'zh-CN,zh;q=0.8',
                'Connection'      => 'keep-alive',
            ];
        }
        $data = [
            'headers' => $header
        ];
        if ($cookies) $data['cookies'] = $cookies;
        try {
            $res = $client->request('GET', $url, $data);
        } catch (Exception $e) {
            return false;
        }


        return $res->getBody()->getContents();
    }
}

if (!function_exists('guzzle_client_post')) {
    function guzzle_client_post($url, $post_data, $header = [], $cli = true)
    {
        if (PHP_SAPI == 'cli' && $cli){
            $urlInfo = parse_url($url);
            if (!empty($urlInfo['scheme']) && $urlInfo['scheme'] == 'https') {
                $port = 443;
                $is_https = true;
                $url = "https://{$urlInfo['host']}{$urlInfo['path']}";
            } else {
                // 如果URL没有指定端口，或者协议不是https，则默认为80
                $port = isset($urlInfo['port']) ? $urlInfo['port'] : 80;
                $is_https = false;
                $url = "http://{$urlInfo['host']}{$urlInfo['path']}";
            }


            $client = new \Swoole\Coroutine\Http\Client($urlInfo['host'],$port,$is_https);
            $client->set(['timeout' => 300]);
            $post_data = json_encode($post_data,1);
            if (!$header) {
                $header = [
                    'Accept'          => '*',
                    'Accept-Encoding' => 'gzip,deflate,sdch',
                    "Host" => $urlInfo['host'],
                    'Accept-Language' => 'zh-CN,zh;q=0.8',
                    'Connection'      => 'keep-alive',
                    'Cache-Control'      => 'no-cache',
                    "Content-Type" => "application/json",
                    "Content-Length" => strlen($post_data),
                    'User-Agent'      => 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.25 Safari/537.36 Core/1.70.3741.400 QQBrowser/10.5.3863.400'
                ];
            }
            $client->setHeaders($header);
            $client->post($url,$post_data);
//            dd($url,$urlInfo,$urlInfo['host'],$port,$client->body);
            return [
                'header' => $client->headers,
                'body'   => $client->body
            ];
        }else{
            $client = new \GuzzleHttp\Client(['http_errors' => false]);
            if (!$header) {
                $header = [
                    'Accept'          => '*',
                    'Accept-Encoding' => 'gzip,deflate,sdch',
                    'Accept-Language' => 'zh-CN,zh;q=0.8',
                    'Connection'      => 'keep-alive',
                    'User-Agent'      => 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.25 Safari/537.36 Core/1.70.3741.400 QQBrowser/10.5.3863.400'
                ];
            }

            $data = [
                'headers' => $header,
                'json'    => $post_data
            ];
            $res  = $client->post($url, $data);
//            dump($res->getBody()->getContents());
            if ($res->getStatusCode() == 500) {
                return [
                    'header' => [],
                    'body'   => $res->getBody()->getContents()
                ];
            }
            return [
                'header' => $res->getHeaders(),
                'body'   => $res->getBody()->getContents()
            ];
        }

    }
}


if (!function_exists('pwd_check')) {
    function pwd_check($pwd)
    {
        $check = get_sys_config('pwd_check');
        //
        sort($check);
        if (strlen($pwd) < 6 || strlen($pwd) > 32) return ['code' => 0, 'msg' => '密码长度6-32位'];
        if (empty($check)) return ['code' => 1, 'msg' => ''];
        if (in_array(1, $check)) {
            return ['code' => 1, 'msg' => ''];
        }

        // $match ='/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]+$/';
        foreach ($check as $v) {
            switch ($v) {
                case 2:
                    $tmp = preg_match('/\d/', $pwd);
                    if (!$tmp) return ['code' => 0, 'msg' => '密码必须包含数字'];
                    break;
                case 3:
                    $tmp = preg_match('/[a-zA-Z]/', $pwd);
                    if (!$tmp) return ['code' => 0, 'msg' => '密码必须要包含字母'];
                    break;
                case 4:
                    $tmp = preg_match('/[\'^£$%&.*()}{@#~?><>,|=_+¬-]/', $pwd);
                    if (!$tmp) return ['code' => 0, 'msg' => '密码必须要包含特殊符号'];
                    break;
            }
        }
        return ['code' => 1, 'msg' => 0];
    }
}

if (!function_exists('username_check')) {
    function username_check($username)
    {
        if (empty($username)) return ['code' => 0, 'msg' => '用户名不能为空'];
        if (preg_match('/[\x{4e00}-\x{9fa5}]/u', $username)) return ['code' => 0, 'msg' => '用户名不能包含中文'];
        $check = get_sys_config('username_check');
        if (in_array(1, $check)) {
            return ['code' => 1, 'msg' => ''];
        }

        foreach ($check as $v) {
            switch ($v) {
                case 2:
                    $tmp = preg_match('/\d/', $username);
                    if (!$tmp) return ['code' => 0, 'msg' => '用户名必须包含一个数字'];
                    break;
                case 3:
                    $tmp = preg_match('/[a-zA-Z]/', $username);
                    if (!$tmp) return ['code' => 0, 'msg' => '用户名必须包含一个字母'];
                    break;
            }
        }
        return ['code' => 1, 'msg' => 0];
    }
}

if (!function_exists('get_curl2')) {
    function get_curl2($url, $post = 0, $referer = 0, $cookie = 0, $httpheaders = 0, $header = 0, $ua = 0, $nobaody = 0, $split = 0)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $httpheader[] = "Accept: application/json";
        $httpheader[] = "Accept-Encoding: gzip,deflate,sdch";
        $httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
        $httpheader[] = "Connection: close";
        if ($httpheaders) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheaders);
        } else {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        }
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HEADER, TRUE);
        }
        if ($cookie) {
            curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        }
        if ($referer) {
            curl_setopt($ch, CURLOPT_REFERER, $referer);
        }
        if ($ua) {
            curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        } else {
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36');
        }
        if ($nobaody) {
            curl_setopt($ch, CURLOPT_NOBODY, 1);

        }
        $ip_long  = array(
            array('607649792', '608174079'),
            array('1038614528', '1039007743'),
            array('1783627776', '1784676351'),
            array('2035023872', '2035154943'),
            array('2078801920', '2079064063'),
            array('-1950089216', '-1948778497'),
            array('-1425539072', '-1425014785'),
            array('-1236271104', '-1235419137'),
            array('-770113536', '-768606209'),
            array('-569376768', '-564133889'),
        );
        $rand_key = mt_rand(0, 9);
        $ip       = long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-FORWARDED-FOR:' . $ip, 'CLIENT-IP:' . $ip));
        curl_setopt($ch, CURLOPT_ENCODING, "gzip");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $ret = curl_exec($ch);
        if ($split) {
            $headerSize    = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $header        = substr($ret, 0, $headerSize);
            $body          = substr($ret, $headerSize);
            $ret           = array();
            $ret['header'] = $header;
            $ret['body']   = $body;
        }
        curl_close($ch);
        return $ret;
    }
}

if (!function_exists('getcookie')) {
    function getcookie($head = 0)
    {
        if (empty($head)) {
            return false;
        }
        $preg = '/Set-Cookie:\ (.*?);/';//获取
        preg_match_all($preg, $head, $view);
        $v = $view[1];
        for ($i = 0; $i < count($v); $i++) {
            $string .= $v[$i] . ';';
        }
        return $string;
    }
}

if (!function_exists('post_request')) {
    function post_request($url, $postdata)
    {
        $data = http_build_query($postdata);

        $options = array(
            'http' => array(
                'method'  => 'POST',
                'header'  => "Content-type: application/x-www-form-urlencoded",
                'content' => $data,
                'timeout' => 5
            )
        );
        $context = stream_context_create($options);
        $result  = file_get_contents($url, false, $context);
        preg_match('/([0-9])\d+/', $http_response_header[0], $matches);
        $responsecode = intval($matches[0]);
        if ($responsecode != 200) {
            $result = array(
                "result" => "success",
                "reason" => "request geetest api fail"
            );
            return json_encode($result);
        } else {
            return $result;
        }
    }
}

if (!function_exists('sendCode')) {
    function sendCode($type, $account, $template, $tag, $has = false)
    {
        $tmp = Cache::get($tag . $account);
        if ($tmp) {
            if ($tmp['time'] > time()) return ['msg' => '请六十秒后重新发送', 'code' => 0];
        }
        if ($has) {
            $has_user = \app\admin\model\User::where($type, $account)->find();
            if ($has_user) return ['msg' => '账号已存在', 'code' => 0];
        }

        switch ($type) {
            case 'mobile':
                try {
                    Event::listen('TemplateAnalysisAfter', function ($templateData) use ($tag, $account) {
                        // 存储验证码
                        if (array_key_exists('code', $templateData['variables'])) {
//                            Cache::set($tag . $account, [
//                                'time' => time() + 60,
//                                'code' => $templateData['variables']['code']
//                            ], 300);
                            Cache::set($tag . getExternalIP(), [
                                'time' => time() + 60,
                                'code' => $templateData['variables']['code']
                            ], 300);
                        }
                        if (array_key_exists('alnum', $templateData['variables'])) {
                            // (new Captcha())->create($mobile . 'user_mobile_verify', $templateData['variables']['alnum']);
//                            Cache::set($tag . $account, [
//                                'time' => time() + 60,
//                                'code' => $templateData['variables']['alnum']
//                            ], 300);
                            Cache::set($tag . getExternalIP(), [
                                'time' => time() + 60,
                                'code' => $templateData['variables']['alnum']
                            ], 300);
                        }

                    });
                    $res = \modules\sms\Sms::send($template, $account);

                } catch (\Exception $e) {
                    Cache::set($tag . $account, [], 300);
                    return ['msg' => $e->getMessage(), 'code' => 0];
                }
                break;
            case 'email':
                // 发送邮件
                $code = rand(1111, 9999);
                $res  = \modules\mail\library\Mail::send($template, $account, ['code' => $code]);
                if ($res['code'] == 1) {
//                    Cache::set($tag . $account, [
//                        'time' => time() + 60,
//                        'code' => $code
//                    ], 300);
                    Cache::set($tag.getExternalIP(), [
                        'time' => time() + 60,
                        'code' => $code
                    ], 300);
                    $res = true;
                } else {
                    $res = false;
                }
                break;
            default:
                return ['msg' => '发送失败', 'code' => 0];
        }
        if ($res) return ['msg' => '发送成功', 'code' => 1];
        else return ['msg' => '发送失败', 'code' => 0];
    }
}

if (!function_exists('create_qrcode')) {
    function create_qrcode($url)
    {
        $create_method = get_sys_config('create_qrcode_method');
        $is_http       = substr($url, 0, 4);
        // if ($is_http) $url = urlencode($url);
        if (substr($url, 0, 7) == '/Upload') return domain() . $url;
        if (empty($create_method) || $create_method == 1) { // 本地
            return domain() . '/qrcode.php?text=' . $url;
        } else {
            return 'http://minico.qq.com/qrcode/get?type=2&r=2&size=350&text=' . $url;
        }
    }
}
if (!function_exists('getExternalIP')) {
    function getExternalIP($is = false)
    {
        if ($is == false) {
            $ip = \think\facade\Cache::get('realIp');
            if (!empty($ip)) return $ip;
        }
        $curl = curl_init('https://api.ipify.org');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $ip = curl_exec($curl);
        curl_close($curl);
        if (!empty($ip)) {
            \think\facade\Cache::set('realIp', $ip, 3600);
        }
        return $ip;
    }
}
if (!function_exists('noticePush')) {
    function noticePush($data = [])
    {
        $jobName      = \app\common\queue\Notice::class;
        $jobQueueName = 'Notice';
        Queue::push($jobName, $data, $jobQueueName);
    }
}

if (!function_exists('isJson')){
    function isJson($string) {
        return (json_decode($string) && (json_last_error() == JSON_ERROR_NONE));
    }
}

if (!function_exists('get_client_ip')){
    /**

     * 获取真实IP

     * @param int $type

     * @param bool $client

     * @return mixed

     */

    function get_client_ip($type = 0,$client=true)

    {

        $type       =  $type ? 1 : 0;

        static $ip  =   NULL;

        if ($ip !== NULL) return $ip[$type];

        if($client){

            if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {

                $arr    =   explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);

                $pos    =   array_search('unknown',$arr);

                if(false !== $pos) unset($arr[$pos]);

                $ip     =   trim($arr[0]);

            }elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {

                $ip     =   $_SERVER['HTTP_CLIENT_IP'];

            }elseif (isset($_SERVER['REMOTE_ADDR'])) {

                $ip     =   $_SERVER['REMOTE_ADDR'];

            }

        }elseif (isset($_SERVER['REMOTE_ADDR'])) {

            $ip     =   $_SERVER['REMOTE_ADDR'];

        }

        // 防止IP伪造

        $long = sprintf("%u",ip2long($ip));

        $ip   = $long ? array($ip, $long) : array('0.0.0.0', 0);

        return $ip[$type];

    }
}

if (!function_exists('getAvatarByEmail')){
    function getAvatarByEmail($email)
    {
        $address = strtolower( trim( $email ) );
        $hash    = md5( $address );
        $url = 'https://cravatar.cn/avatar/' . $hash.'.png?s=150';
        return $url;
    }
}
