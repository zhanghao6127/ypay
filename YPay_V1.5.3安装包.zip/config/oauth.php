<?php
// +----------------------------------------------------------------------
// | 第三方授权登录配置
// +----------------------------------------------------------------------

return [
    'qq'          => [
        'app_id'       => '',#qq#
        'app_secret'   => '',#qq#
        'callback_url' => domain().'/api/OAuthLogin/notify',#qq#
    ],
    'wechat_scan' => [
        'app_id'       => '',#wechat_scan#
        'app_secret'   => '',#wechat_scan#
        'callback_url' => domain().'/api/OAuthLogin/notify',#wechat_scan#
    ],
    'wechat_mp'   => [
        'app_id'       => '',#wechat_mp#
        'app_secret'   => '',#wechat_mp#
        'callback_url' => domain().'/api/OAuthLogin/notify',#wechat_mp#
    ],
];