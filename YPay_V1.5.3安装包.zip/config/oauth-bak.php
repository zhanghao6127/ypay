<?php
// +----------------------------------------------------------------------
// | 第三方授权登录配置
// +----------------------------------------------------------------------

return [
    'qq'          => [
        'app_id'       => '101986460',#qq#
        'app_secret'   => '096c338aa40da38100b9183eed13ad9c',#qq#
        'callback_url' => 'https://cspay.yfxw.cn/api/OAuthLogin/notify',#qq#
    ],
    'wechat_scan' => [
        'app_id'       => '101986460',#wechat_scan#
        'app_secret'   => '096c338aa40da38100b9183eed13ad9c',#wechat_scan#
        'callback_url' => 'https://cspay.yfxw.cn/api/OAuthLogin/notify',#wechat_scan#
    ],
    'wechat_mp'   => [
        'app_id'       => '',#wechat_mp#
        'app_secret'   => '',#wechat_mp#
        'callback_url' => '',#wechat_mp#
    ],
];