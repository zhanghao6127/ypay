/*
 Navicat Premium Data Transfer

 Source Server         : merchants
 Source Server Type    : MySQL
 Source Server Version : 50738
 Source Host           : 127.0.0.1:3306
 Source Schema         : merchants

 Target Server Type    : MySQL
 Target Server Version : 50738
 File Encoding         : 65001

 Date: 14/04/2024 22:21:53
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for me_account
-- ----------------------------
DROP TABLE IF EXISTS `me_account`;
CREATE TABLE `me_account`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `key` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '通道标识',
  `type` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '通道类型',
  `user_id` int(11) NOT NULL DEFAULT 0 COMMENT '会员ID',
  `account` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '支付宝Pid/微信云端GUID/QQ号/微信昵称',
  `cloud_id` int(11) NULL DEFAULT 0 COMMENT '云端ID',
  `appid` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT 'appid',
  `public_key` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '公钥',
  `private_key` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '私钥/cookid',
  `status` int(1) NOT NULL DEFAULT 0 COMMENT '收款开关:0=禁用,1=启用',
  `online_status` int(1) NOT NULL DEFAULT 0 COMMENT '在线状态:0=下线,1=在线',
  `qr_code` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '二维码地址',
  `h5_url` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '手机端跳转地址',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '备注',
  `alipay_money` float(10, 2) NULL DEFAULT 0.00 COMMENT '支付宝余额',
  `weigh` int(10) NULL DEFAULT 0 COMMENT '权重',
  `loginid` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '支付宝登录二维码登录ID',
  `create_time` bigint(20) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_account
-- ----------------------------

-- ----------------------------
-- Table structure for me_admin
-- ----------------------------
DROP TABLE IF EXISTS `me_admin`;
CREATE TABLE `me_admin`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '昵称',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '头像',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '邮箱',
  `mobile` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '手机',
  `login_failure` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '登录失败次数',
  `last_login_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '上次登录时间',
  `last_login_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '上次登录IP',
  `password` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
  `salt` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码盐',
  `motto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '签名',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '状态:0=禁用,1=启用',
  `update_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '管理员表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_admin
-- ----------------------------
INSERT INTO `me_admin` VALUES (1, 'admin', 'Admin', '', 'admin@buildadmin.com', '18888888888', 0, 1713103711, '127.0.0.1', 'c6159637bbf1b7de254e5aba4fabc06c', 'hfP0vEdsmUcwgCWy', '', '1', 1713103711, 1712046440);

-- ----------------------------
-- Table structure for me_admin_group
-- ----------------------------
DROP TABLE IF EXISTS `me_admin_group`;
CREATE TABLE `me_admin_group`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '上级分组',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '组名',
  `rules` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '权限规则ID',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '状态:0=禁用,1=启用',
  `update_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '管理分组表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_admin_group
-- ----------------------------
INSERT INTO `me_admin_group` VALUES (1, 0, '超级管理组', '*', '1', 1712046440, 1712046440);
INSERT INTO `me_admin_group` VALUES (2, 1, '一级管理员', '1,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,77,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,89', '1', 1712046440, 1712046440);
INSERT INTO `me_admin_group` VALUES (3, 2, '二级管理员', '21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43', '1', 1712046440, 1712046440);
INSERT INTO `me_admin_group` VALUES (4, 3, '三级管理员', '55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75', '1', 1712046440, 1712046440);

-- ----------------------------
-- Table structure for me_admin_group_access
-- ----------------------------
DROP TABLE IF EXISTS `me_admin_group_access`;
CREATE TABLE `me_admin_group_access`  (
  `uid` int(10) UNSIGNED NOT NULL COMMENT '管理员ID',
  `group_id` int(10) UNSIGNED NOT NULL COMMENT '分组ID',
  INDEX `uid`(`uid`) USING BTREE,
  INDEX `group_id`(`group_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '管理分组映射表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_admin_group_access
-- ----------------------------
INSERT INTO `me_admin_group_access` VALUES (1, 1);

-- ----------------------------
-- Table structure for me_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `me_admin_log`;
CREATE TABLE `me_admin_log`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '管理员ID',
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '管理员用户名',
  `url` varchar(1500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作Url',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '日志标题',
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '请求数据',
  `ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'IP',
  `useragent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'User-Agent',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 309 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '管理员日志表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_admin_log
-- ----------------------------
INSERT INTO `me_admin_log` VALUES (303, 1, 'admin', '/admin/Index/login', '未知(login)', '{\"username\":\"admin\",\"password\":\"***\",\"keep\":\"\",\"captchaId\":\"8ee12af0-30e4-4040-ad6d-0d90ad4c73d8\",\"captchaInfo\":\"\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1713102979);
INSERT INTO `me_admin_log` VALUES (304, 1, 'admin', '/admin/routine.Attachment/del?ids[]=3&ids[]=2&ids[]=1', '附件管理-删除', '{\"ids\":[\"3\",\"2\",\"1\"]}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1713103559);
INSERT INTO `me_admin_log` VALUES (305, 1, 'admin', '/admin/security.DataRecycleLog/del?ids[]=1', '数据回收站-删除', '{\"ids\":[\"1\"]}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1713103565);
INSERT INTO `me_admin_log` VALUES (306, 1, 'admin', '/admin/security.SensitiveDataLog/del?ids[]=1', '敏感数据修改记录-删除', '{\"ids\":[\"1\"]}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1713103575);
INSERT INTO `me_admin_log` VALUES (307, 1, 'admin', '/admin/Order/del?ids[]=115', '订单日志-删除', '{\"ids\":[\"115\"]}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1713103687);
INSERT INTO `me_admin_log` VALUES (308, 1, 'admin', '/admin/Cloud/del?ids[]=1', '云端管理-删除', '{\"ids\":[\"1\"]}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1713103705);

-- ----------------------------
-- Table structure for me_admin_rule
-- ----------------------------
DROP TABLE IF EXISTS `me_admin_rule`;
CREATE TABLE `me_admin_rule`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '上级菜单',
  `type` enum('menu_dir','menu','button') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'menu' COMMENT '类型:menu_dir=菜单目录,menu=菜单项,button=页面按钮',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则名称',
  `path` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '路由路径',
  `icon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '图标',
  `menu_type` enum('tab','link','iframe') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '菜单类型:tab=选项卡,link=链接,iframe=Iframe',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Url',
  `component` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '组件路径',
  `keepalive` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '缓存:0=关闭,1=开启',
  `extend` enum('none','add_rules_only','add_menu_only') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none' COMMENT '扩展属性:none=无,add_rules_only=只添加为路由,add_menu_only=只添加为菜单',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `weigh` int(11) NOT NULL DEFAULT 0 COMMENT '权重',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '状态:0=禁用,1=启用',
  `update_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `pid`(`pid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 168 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '菜单和权限规则表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_admin_rule
-- ----------------------------
INSERT INTO `me_admin_rule` VALUES (1, 0, 'menu', '控制台', 'dashboard', 'dashboard', 'fa fa-dashboard', 'tab', '', '/src/views/backend/dashboard.vue', 1, 'none', 'Remark lang', 999, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (2, 0, 'menu_dir', '权限管理', 'auth', 'auth', 'fa fa-group', NULL, '', '', 0, 'none', '', 100, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (3, 2, 'menu', '角色组管理', 'auth/group', 'auth/group', 'fa fa-group', 'tab', '', '/src/views/backend/auth/group/index.vue', 1, 'none', 'Remark lang', 99, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (4, 3, 'button', '查看', 'auth/group/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (5, 3, 'button', '添加', 'auth/group/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (6, 3, 'button', '编辑', 'auth/group/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (7, 3, 'button', '删除', 'auth/group/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (8, 2, 'menu', '管理员管理', 'auth/admin', 'auth/admin', 'el-icon-UserFilled', 'tab', '', '/src/views/backend/auth/admin/index.vue', 1, 'none', '', 98, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (9, 8, 'button', '查看', 'auth/admin/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (10, 8, 'button', '添加', 'auth/admin/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (11, 8, 'button', '编辑', 'auth/admin/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (12, 8, 'button', '删除', 'auth/admin/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (13, 2, 'menu', '菜单规则管理', 'auth/rule', 'auth/rule', 'el-icon-Grid', 'tab', '', '/src/views/backend/auth/rule/index.vue', 1, 'none', '', 97, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (14, 13, 'button', '查看', 'auth/rule/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (15, 13, 'button', '添加', 'auth/rule/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (16, 13, 'button', '编辑', 'auth/rule/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (17, 13, 'button', '删除', 'auth/rule/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (18, 13, 'button', '快速排序', 'auth/rule/sortable', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (19, 2, 'menu', '管理员日志管理', 'auth/adminLog', 'auth/adminLog', 'el-icon-List', 'tab', '', '/src/views/backend/auth/adminLog/index.vue', 1, 'none', '', 96, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (20, 19, 'button', '查看', 'auth/adminLog/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (21, 0, 'menu_dir', '会员管理', 'user', 'user', 'fa fa-drivers-license', NULL, '', '', 0, 'none', '', 95, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (22, 21, 'menu', '会员管理', 'user/user', 'user/user', 'fa fa-user', 'tab', '', '/src/views/backend/user/user/index.vue', 1, 'none', '', 94, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (23, 22, 'button', '查看', 'user/user/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (24, 22, 'button', '添加', 'user/user/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (25, 22, 'button', '编辑', 'user/user/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (26, 22, 'button', '删除', 'user/user/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (27, 21, 'menu', '会员分组管理', 'user/group', 'user/group', 'fa fa-group', 'tab', '', '/src/views/backend/user/group/index.vue', 1, 'none', '', 93, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (28, 27, 'button', '查看', 'user/group/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (29, 27, 'button', '添加', 'user/group/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (30, 27, 'button', '编辑', 'user/group/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (31, 27, 'button', '删除', 'user/group/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (32, 21, 'menu', '会员规则管理', 'user/rule', 'user/rule', 'fa fa-th-list', 'tab', '', '/src/views/backend/user/rule/index.vue', 1, 'none', '', 92, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (33, 32, 'button', '查看', 'user/rule/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (34, 32, 'button', '添加', 'user/rule/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (35, 32, 'button', '编辑', 'user/rule/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (36, 32, 'button', '删除', 'user/rule/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (37, 32, 'button', '快速排序', 'user/rule/sortable', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (38, 160, 'menu', '会员余额管理', 'user/moneyLog', 'user/moneyLog', 'el-icon-Money', 'tab', '', '/src/views/backend/user/moneyLog/index.vue', 1, 'none', '', 91, '1', 1712549719, 1712046440);
INSERT INTO `me_admin_rule` VALUES (39, 38, 'button', '查看', 'user/moneyLog/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (40, 38, 'button', '添加', 'user/moneyLog/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (41, 21, 'menu', '会员积分管理', 'user/scoreLog', 'user/scoreLog', 'el-icon-Discount', 'tab', '', '/src/views/backend/user/scoreLog/index.vue', 1, 'none', '', 90, '0', 1712482669, 1712046440);
INSERT INTO `me_admin_rule` VALUES (42, 41, 'button', '查看', 'user/scoreLog/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (43, 41, 'button', '添加', 'user/scoreLog/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (44, 0, 'menu_dir', '常规管理', 'routine', 'routine', 'fa fa-cogs', NULL, '', '', 0, 'none', '', 89, '1', 1712482914, 1712046440);
INSERT INTO `me_admin_rule` VALUES (45, 44, 'menu', '系统配置', 'routine/config', 'routine/config', 'el-icon-Tools', 'tab', '', '/src/views/backend/routine/config/index.vue', 1, 'none', '', 88, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (46, 45, 'button', '查看', 'routine/config/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (47, 45, 'button', '编辑', 'routine/config/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (48, 44, 'menu', '附件管理', 'routine/attachment', 'routine/attachment', 'fa fa-folder', 'tab', '', '/src/views/backend/routine/attachment/index.vue', 1, 'none', 'Remark lang', 87, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (49, 48, 'button', '查看', 'routine/attachment/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (50, 48, 'button', '编辑', 'routine/attachment/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (51, 48, 'button', '删除', 'routine/attachment/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (52, 44, 'menu', '个人资料', 'routine/adminInfo', 'routine/adminInfo', 'fa fa-user', 'tab', '', '/src/views/backend/routine/adminInfo.vue', 1, 'none', '', 86, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (53, 52, 'button', '查看', 'routine/adminInfo/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (54, 52, 'button', '编辑', 'routine/adminInfo/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (55, 0, 'menu_dir', '数据安全管理', 'security', 'security', 'fa fa-shield', NULL, '', '', 0, 'none', '', 85, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (56, 55, 'menu', '数据回收站', 'security/dataRecycleLog', 'security/dataRecycleLog', 'fa fa-database', 'tab', '', '/src/views/backend/security/dataRecycleLog/index.vue', 1, 'none', '', 84, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (57, 56, 'button', '查看', 'security/dataRecycleLog/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (58, 56, 'button', '删除', 'security/dataRecycleLog/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (59, 56, 'button', '还原', 'security/dataRecycleLog/restore', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (60, 56, 'button', '查看详情', 'security/dataRecycleLog/info', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (61, 55, 'menu', '敏感数据修改记录', 'security/sensitiveDataLog', 'security/sensitiveDataLog', 'fa fa-expeditedssl', 'tab', '', '/src/views/backend/security/sensitiveDataLog/index.vue', 1, 'none', '', 83, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (62, 61, 'button', '查看', 'security/sensitiveDataLog/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (63, 61, 'button', '删除', 'security/sensitiveDataLog/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (64, 61, 'button', '回滚', 'security/sensitiveDataLog/rollback', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (65, 61, 'button', '查看详情', 'security/sensitiveDataLog/info', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (66, 55, 'menu', '数据回收规则管理', 'security/dataRecycle', 'security/dataRecycle', 'fa fa-database', 'tab', '', '/src/views/backend/security/dataRecycle/index.vue', 1, 'none', 'Remark lang', 82, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (67, 66, 'button', '查看', 'security/dataRecycle/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (68, 66, 'button', '添加', 'security/dataRecycle/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (69, 66, 'button', '编辑', 'security/dataRecycle/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (70, 66, 'button', '删除', 'security/dataRecycle/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (71, 55, 'menu', '敏感字段规则管理', 'security/sensitiveData', 'security/sensitiveData', 'fa fa-expeditedssl', 'tab', '', '/src/views/backend/security/sensitiveData/index.vue', 1, 'none', 'Remark lang', 81, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (72, 71, 'button', '查看', 'security/sensitiveData/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (73, 71, 'button', '添加', 'security/sensitiveData/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (74, 71, 'button', '编辑', 'security/sensitiveData/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (75, 71, 'button', '删除', 'security/sensitiveData/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (76, 0, 'menu', 'BuildAdmin', 'buildadmin', 'buildadmin', 'local-logo', 'link', 'https://doc.buildadmin.com', '', 0, 'none', '', 0, '0', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (77, 45, 'button', '添加', 'routine/config/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (78, 0, 'menu', '模块市场', 'moduleStore/moduleStore', 'moduleStore', 'el-icon-GoodsFilled', 'tab', '', '/src/views/backend/module/index.vue', 0, 'none', '', 86, '0', 1713030241, 1712046440);
INSERT INTO `me_admin_rule` VALUES (79, 78, 'button', '查看', 'moduleStore/moduleStore/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (80, 78, 'button', '安装', 'moduleStore/moduleStore/install', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (81, 78, 'button', '调整状态', 'moduleStore/moduleStore/changeState', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (82, 78, 'button', '卸载', 'moduleStore/moduleStore/uninstall', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (83, 78, 'button', '更新', 'moduleStore/moduleStore/update', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (84, 0, 'menu', 'CRUD代码生成', 'crud/crud', 'crud/crud', 'fa fa-code', 'tab', '', '/src/views/backend/crud/index.vue', 0, 'none', '', 80, '0', 1713032627, 1712046440);
INSERT INTO `me_admin_rule` VALUES (85, 84, 'button', '查看', 'crud/crud/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (86, 84, 'button', '生成', 'crud/crud/generate', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (87, 84, 'button', '删除', 'crud/crud/delete', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (88, 45, 'button', '删除', 'routine/config/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (89, 1, 'button', '查看', 'dashboard/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712046440, 1712046440);
INSERT INTO `me_admin_rule` VALUES (90, 130, 'menu', '云端管理', 'cloud', 'cloud', 'fa fa-cloud', 'tab', '', '/src/views/backend/cloud/index.vue', 1, 'none', '', 0, '1', 1712485472, 1712047236);
INSERT INTO `me_admin_rule` VALUES (91, 90, 'button', '查看', 'cloud/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712047236, 1712047236);
INSERT INTO `me_admin_rule` VALUES (92, 90, 'button', '添加', 'cloud/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712047236, 1712047236);
INSERT INTO `me_admin_rule` VALUES (93, 90, 'button', '编辑', 'cloud/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712047236, 1712047236);
INSERT INTO `me_admin_rule` VALUES (94, 90, 'button', '删除', 'cloud/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712047236, 1712047236);
INSERT INTO `me_admin_rule` VALUES (95, 90, 'button', '快速排序', 'cloud/sortable', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712047236, 1712047236);
INSERT INTO `me_admin_rule` VALUES (130, 0, 'menu', '通道管理', 'channel', 'channel', 'el-icon-Menu', 'tab', '', '/src/views/backend/channel/index.vue', 1, 'none', '', 0, '1', 1712490904, 1712484820);
INSERT INTO `me_admin_rule` VALUES (131, 130, 'button', '查看', 'channel/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484821, 1712484821);
INSERT INTO `me_admin_rule` VALUES (132, 130, 'button', '添加', 'channel/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484821, 1712484821);
INSERT INTO `me_admin_rule` VALUES (133, 130, 'button', '编辑', 'channel/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484821, 1712484821);
INSERT INTO `me_admin_rule` VALUES (134, 130, 'button', '删除', 'channel/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484821, 1712484821);
INSERT INTO `me_admin_rule` VALUES (135, 130, 'button', '快速排序', 'channel/sortable', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484821, 1712484821);
INSERT INTO `me_admin_rule` VALUES (136, 130, 'menu', '通道类型管理', 'channel/type', 'channel/type', 'fa fa-certificate', 'tab', '', '/src/views/backend/channel/type/index.vue', 1, 'none', '', 0, '1', 1712484837, 1712484837);
INSERT INTO `me_admin_rule` VALUES (137, 136, 'button', '查看', 'channel/type/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484837, 1712484837);
INSERT INTO `me_admin_rule` VALUES (138, 136, 'button', '添加', 'channel/type/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484837, 1712484837);
INSERT INTO `me_admin_rule` VALUES (139, 136, 'button', '编辑', 'channel/type/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484837, 1712484837);
INSERT INTO `me_admin_rule` VALUES (140, 136, 'button', '删除', 'channel/type/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484837, 1712484837);
INSERT INTO `me_admin_rule` VALUES (141, 136, 'button', '快速排序', 'channel/type/sortable', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484837, 1712484837);
INSERT INTO `me_admin_rule` VALUES (142, 130, 'menu', '通道支付类型管理', 'channel/paytype', 'channel/paytype', 'fa fa-paypal', 'tab', '', '/src/views/backend/channel/paytype/index.vue', 1, 'none', '', 0, '1', 1712484868, 1712484868);
INSERT INTO `me_admin_rule` VALUES (143, 142, 'button', '查看', 'channel/paytype/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484868, 1712484868);
INSERT INTO `me_admin_rule` VALUES (144, 142, 'button', '添加', 'channel/paytype/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484868, 1712484868);
INSERT INTO `me_admin_rule` VALUES (145, 142, 'button', '编辑', 'channel/paytype/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484868, 1712484868);
INSERT INTO `me_admin_rule` VALUES (146, 142, 'button', '删除', 'channel/paytype/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484868, 1712484868);
INSERT INTO `me_admin_rule` VALUES (147, 142, 'button', '快速排序', 'channel/paytype/sortable', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712484868, 1712484868);
INSERT INTO `me_admin_rule` VALUES (148, 130, 'menu', '通道管理', 'channel/lists', 'channel/lists', 'fa fa-meetup', 'tab', '', '/src/views/backend/channel/lists/index.vue', 1, 'none', '', 0, '1', 1712485911, 1712485911);
INSERT INTO `me_admin_rule` VALUES (149, 148, 'button', '查看', 'channel/lists/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712485911, 1712485911);
INSERT INTO `me_admin_rule` VALUES (150, 148, 'button', '添加', 'channel/lists/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712485911, 1712485911);
INSERT INTO `me_admin_rule` VALUES (151, 148, 'button', '编辑', 'channel/lists/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712485911, 1712485911);
INSERT INTO `me_admin_rule` VALUES (152, 148, 'button', '删除', 'channel/lists/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712485911, 1712485911);
INSERT INTO `me_admin_rule` VALUES (153, 148, 'button', '快速排序', 'channel/lists/sortable', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712485911, 1712485911);
INSERT INTO `me_admin_rule` VALUES (154, 21, 'menu', '会员套餐管理', 'user/package', 'user/package', 'fa fa-vimeo', 'tab', '', '/src/views/backend/user/package/index.vue', 1, 'none', '', 0, '1', 1712495881, 1712495881);
INSERT INTO `me_admin_rule` VALUES (155, 154, 'button', '查看', 'user/package/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712495881, 1712495881);
INSERT INTO `me_admin_rule` VALUES (156, 154, 'button', '添加', 'user/package/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712495881, 1712495881);
INSERT INTO `me_admin_rule` VALUES (157, 154, 'button', '编辑', 'user/package/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712495881, 1712495881);
INSERT INTO `me_admin_rule` VALUES (158, 154, 'button', '删除', 'user/package/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712495881, 1712495881);
INSERT INTO `me_admin_rule` VALUES (159, 154, 'button', '快速排序', 'user/package/sortable', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712495881, 1712495881);
INSERT INTO `me_admin_rule` VALUES (160, 0, 'menu_dir', '商城管理', 'shop', '', 'el-icon-Briefcase', 'tab', '', '', 1, 'none', '', 0, '1', 1712549686, 1712549686);
INSERT INTO `me_admin_rule` VALUES (161, 160, 'menu', '订单日志', 'order', 'order', 'fa fa-shopping-cart', 'tab', '', '/src/views/backend/order/index.vue', 1, 'none', '', 0, '1', 1713074085, 1712770095);
INSERT INTO `me_admin_rule` VALUES (162, 161, 'button', '查看', 'order/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712770095, 1712770095);
INSERT INTO `me_admin_rule` VALUES (163, 161, 'button', '添加', 'order/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712770095, 1712770095);
INSERT INTO `me_admin_rule` VALUES (164, 161, 'button', '编辑', 'order/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712770095, 1712770095);
INSERT INTO `me_admin_rule` VALUES (165, 161, 'button', '删除', 'order/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712770095, 1712770095);
INSERT INTO `me_admin_rule` VALUES (166, 161, 'button', '快速排序', 'order/sortable', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1712770095, 1712770095);
INSERT INTO `me_admin_rule` VALUES (167, 0, 'menu', '在线更新', 'zxaz', 'zxaz', 'fa fa-cloud-upload', 'tab', '', '/src/views/backend/zxaz/index.vue', 0, 'none', '', 0, '1', 1713084884, 1713074357);

-- ----------------------------
-- Table structure for me_area
-- ----------------------------
DROP TABLE IF EXISTS `me_area`;
CREATE TABLE `me_area`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) UNSIGNED NULL DEFAULT NULL COMMENT '父id',
  `shortname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '简称',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '名称',
  `mergename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '全称',
  `level` tinyint(3) UNSIGNED NULL DEFAULT NULL COMMENT '层级:1=省,2=市,3=区/县',
  `pinyin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '拼音',
  `code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '长途区号',
  `zip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '邮编',
  `first` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '首字母',
  `lng` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '经度',
  `lat` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '纬度',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `pid`(`pid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '省份地区表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_area
-- ----------------------------

-- ----------------------------
-- Table structure for me_attachment
-- ----------------------------
DROP TABLE IF EXISTS `me_attachment`;
CREATE TABLE `me_attachment`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `topic` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '细目',
  `admin_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '上传管理员ID',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '上传用户ID',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '物理路径',
  `width` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '宽度',
  `height` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '高度',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '原始名称',
  `size` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '大小',
  `mimetype` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'mime类型',
  `quote` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '上传(引用)次数',
  `storage` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '存储方式',
  `sha1` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'sha1编码',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  `last_upload_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '最后上传时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '附件表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_attachment
-- ----------------------------

-- ----------------------------
-- Table structure for me_captcha
-- ----------------------------
DROP TABLE IF EXISTS `me_captcha`;
CREATE TABLE `me_captcha`  (
  `key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '验证码Key',
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '验证码(加密后)',
  `captcha` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '验证码数据',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  `expire_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`key`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '验证码表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_captcha
-- ----------------------------
INSERT INTO `me_captcha` VALUES ('23f9f7bae7fd58abfff431d13b978139', '8c191b8760ba0f48903fc6d252b33d0b', '{\"text\":[{\"size\":21,\"icon\":false,\"text\":\"游\",\"width\":26,\"height\":27,\"x\":147,\"y\":58},{\"size\":16,\"icon\":true,\"text\":\"<帆船>\",\"width\":36,\"height\":32,\"name\":\"sailboat\",\"x\":36,\"y\":117}],\"width\":350,\"height\":200}', 1712804953, 1712805553);

-- ----------------------------
-- Table structure for me_channel_paytype
-- ----------------------------
DROP TABLE IF EXISTS `me_channel_paytype`;
CREATE TABLE `me_channel_paytype`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '类型名称',
  `type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '类型code',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '状态:0=禁用,1=启用',
  `create_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '通道支付类型表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_channel_paytype
-- ----------------------------
INSERT INTO `me_channel_paytype` VALUES (1, '支付宝', 'alipay', 1, 1712495369, 1712495369);
INSERT INTO `me_channel_paytype` VALUES (2, '微信', 'wxpay', 1, 1712495380, 1712495380);
INSERT INTO `me_channel_paytype` VALUES (3, 'QQ', 'qqpay', 1, 1712495388, 1712495388);

-- ----------------------------
-- Table structure for me_channel_type
-- ----------------------------
DROP TABLE IF EXISTS `me_channel_type`;
CREATE TABLE `me_channel_type`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '通道类型名称',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '支付类型',
  `code` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '通道类型',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '状态:0=禁用,1=启用',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `create_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '通道类型表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_channel_type
-- ----------------------------
INSERT INTO `me_channel_type` VALUES (1, '支付宝当面付', 'alipay', 'alipay_dmf', 1, '', 1712484166, 1712484166);
INSERT INTO `me_channel_type` VALUES (2, '支付宝个人免挂', 'alipay', 'alipay_grmg', 1, '', 1712486942, 1712486942);
INSERT INTO `me_channel_type` VALUES (3, '支付宝账单查询', 'alipay', 'alipay_bill', 1, '', 1712486942, 1712486942);

-- ----------------------------
-- Table structure for me_cloud
-- ----------------------------
DROP TABLE IF EXISTS `me_cloud`;
CREATE TABLE `me_cloud`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT 1 COMMENT '状态:0=禁用,1=启用',
  `cloud_type` enum('1','2','3') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '云端类型:1=V1,2=V2,3=V3',
  `type` enum('1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '类型:1=微信,2=QQ',
  `address` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '地址',
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `weigh` int(11) NULL DEFAULT 0 COMMENT '权重',
  `update_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '修改时间',
  `create_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '云端管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_cloud
-- ----------------------------

-- ----------------------------
-- Table structure for me_config
-- ----------------------------
DROP TABLE IF EXISTS `me_config`;
CREATE TABLE `me_config`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '变量名',
  `group` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分组',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '变量标题',
  `tip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '变量描述',
  `type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '变量输入组件类型',
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '变量值',
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '字典数据',
  `rule` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '验证规则',
  `extend` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '扩展属性',
  `allow_del` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '允许删除:0=否,1=是',
  `weigh` int(11) NOT NULL DEFAULT 0 COMMENT '权重',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '系统配置' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_config
-- ----------------------------
INSERT INTO `me_config` VALUES (1, 'config_group', 'basics', 'Config group', '', 'array', '[{\"key\":\"basics\",\"value\":\"Basics\"},{\"key\":\"mail\",\"value\":\"Mail\"},{\"key\":\"config_quick_entrance\",\"value\":\"Config Quick entrance\"},{\"key\":\"pay_config\",\"value\":\"\\u652f\\u4ed8\\u914d\\u7f6e\"}]', NULL, 'required', '', 0, -1);
INSERT INTO `me_config` VALUES (2, 'site_name', 'basics', 'Site Name', '站点名称', 'string', 'YPay', NULL, 'required', '', 0, 99);
INSERT INTO `me_config` VALUES (3, 'record_number', 'basics', 'Record number', '域名备案号', 'string', '渝ICP备8888888号-1', NULL, '', '', 0, 0);
INSERT INTO `me_config` VALUES (4, 'version', 'basics', 'Version number', '系统版本号', 'string', 'V1.0.2', NULL, 'required', '', 0, 0);
INSERT INTO `me_config` VALUES (5, 'time_zone', 'basics', 'time zone', '', 'string', 'Asia/Shanghai', NULL, 'required', '', 0, 0);
INSERT INTO `me_config` VALUES (6, 'no_access_ip', 'basics', 'No access ip', '禁止访问站点的ip列表,一行一个', 'textarea', '', NULL, '', '', 0, 0);
INSERT INTO `me_config` VALUES (7, 'smtp_server', 'mail', 'smtp server', '', 'string', 'smtp.qq.com', NULL, '', '', 0, 9);
INSERT INTO `me_config` VALUES (8, 'smtp_port', 'mail', 'smtp port', '', 'string', '465', NULL, '', '', 0, 8);
INSERT INTO `me_config` VALUES (9, 'smtp_user', 'mail', 'smtp user', '', 'string', NULL, NULL, '', '', 0, 7);
INSERT INTO `me_config` VALUES (10, 'smtp_pass', 'mail', 'smtp pass', '', 'string', NULL, NULL, '', '', 0, 6);
INSERT INTO `me_config` VALUES (11, 'smtp_verification', 'mail', 'smtp verification', '', 'select', 'SSL', '{\"SSL\":\"SSL\",\"TLS\":\"TLS\"}', '', '', 0, 5);
INSERT INTO `me_config` VALUES (12, 'smtp_sender_mail', 'mail', 'smtp sender mail', '', 'string', NULL, NULL, 'email', '', 0, 4);
INSERT INTO `me_config` VALUES (13, 'config_quick_entrance', 'config_quick_entrance', 'Config Quick entrance', '', 'array', '[{\"key\":\"\\u6570\\u636e\\u56de\\u6536\\u89c4\\u5219\\u914d\\u7f6e\",\"value\":\"security\\/dataRecycle\"},{\"key\":\"\\u654f\\u611f\\u6570\\u636e\\u89c4\\u5219\\u914d\\u7f6e\",\"value\":\"security\\/sensitiveData\"}]', NULL, '', '', 0, 0);
INSERT INTO `me_config` VALUES (15, 'config_alipay_appid', 'pay_config', '支付宝APPid', '支付宝APPID', 'string', NULL, NULL, ' ', '', 0, 0);
INSERT INTO `me_config` VALUES (16, 'config_alipay_private_cert', 'pay_config', '支付宝密钥', '支付宝用户私钥', 'textarea', NULL, NULL, ' ', '', 0, 0);
INSERT INTO `me_config` VALUES (18, 'config_alipay_public_cert', 'pay_config', '支付宝公钥', '支付宝用户公钥', 'textarea', NULL, NULL, ' ', '', 0, 0);
INSERT INTO `me_config` VALUES (19, 'activate_key', 'activate_config', '用户激活ID', '用户激活ID', 'string', NULL, NULL, 'required', '', 1, 0);
INSERT INTO `me_config` VALUES (20, 'activate_secret', 'activate_config', '用户激活密钥', '用户激活密钥', 'string', NULL, NULL, 'required', '', 1, 0);
INSERT INTO `me_config` VALUES (21, 'activate_cache', 'activate_config', '用户激活缓存key', '用户激活缓存key', 'string', NULL, NULL, 'required', '', 1, 0);
INSERT INTO `me_config` VALUES (23, 'site_logo', 'basics', '前台logo', ' ', 'image', NULL, NULL, '', '', 1, 97);
INSERT INTO `me_config` VALUES (24, 'site_ico', 'basics', '前台Favicon', '', 'image', NULL, NULL, '', '', 1, 98);

-- ----------------------------
-- Table structure for me_crud_log
-- ----------------------------
DROP TABLE IF EXISTS `me_crud_log`;
CREATE TABLE `me_crud_log`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `table_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据表名',
  `table` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '数据表数据',
  `fields` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '字段数据',
  `status` enum('delete','success','error','start') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'start' COMMENT '状态:delete=已删除,success=成功,error=失败,start=生成中',
  `connection` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据库连接配置标识',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'CRUD记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_crud_log
-- ----------------------------

-- ----------------------------
-- Table structure for me_migrations
-- ----------------------------

-- ----------------------------
-- Records of me_migrations
-- ----------------------------

-- ----------------------------
-- Table structure for me_order
-- ----------------------------
DROP TABLE IF EXISTS `me_order`;
CREATE TABLE `me_order`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '用户ID',
  `channel_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '通道ID',
  `out_trade_no` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '外部订单号',
  `trade_no` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '内部单号',
  `alipay_order_no` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '阿里云订单号',
  `pay_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '支付类型',
  `notify_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '异步回调地址',
  `return_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '同步地址',
  `money` int(10) NOT NULL DEFAULT 0 COMMENT '订单金额',
  `truemoney` int(10) NOT NULL DEFAULT 0 COMMENT '订单实际支付金额',
  `status` int(10) NOT NULL DEFAULT 0 COMMENT '状态:0=未支付,1=已支付',
  `out_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '订单超时时间',
  `end_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '订单支付时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '支付二维码',
  `h5_qrurl` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'h5二维码url',
  `attach` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '外部参数 支付完成后原样返回',
  `callback` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '回调情况',
  `create_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '会员订单比表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_order
-- ----------------------------

-- ----------------------------
-- Table structure for me_security_data_recycle
-- ----------------------------
DROP TABLE IF EXISTS `me_security_data_recycle`;
CREATE TABLE `me_security_data_recycle`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则名称',
  `controller` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '控制器',
  `controller_as` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '控制器别名',
  `data_table` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '对应数据表',
  `connection` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据库连接配置标识',
  `primary_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据表主键',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '状态:0=禁用,1=启用',
  `update_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '回收规则表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_security_data_recycle
-- ----------------------------
INSERT INTO `me_security_data_recycle` VALUES (1, '管理员', 'auth/Admin.php', 'auth/admin', 'admin', '', 'id', '1', 1712046440, 1712046440);
INSERT INTO `me_security_data_recycle` VALUES (2, '管理员日志', 'auth/AdminLog.php', 'auth/adminlog', 'admin_log', '', 'id', '1', 1712046440, 1712046440);
INSERT INTO `me_security_data_recycle` VALUES (3, '菜单规则', 'auth/Menu.php', 'auth/menu', 'menu_rule', '', 'id', '1', 1712046440, 1712046440);
INSERT INTO `me_security_data_recycle` VALUES (4, '系统配置项', 'routine/Config.php', 'routine/config', 'config', '', 'id', '1', 1712046440, 1712046440);
INSERT INTO `me_security_data_recycle` VALUES (5, '会员', 'user/User.php', 'user/user', 'user', '', 'id', '1', 1712046440, 1712046440);
INSERT INTO `me_security_data_recycle` VALUES (6, '数据回收规则', 'security/DataRecycle.php', 'security/datarecycle', 'security_data_recycle', '', 'id', '1', 1712046440, 1712046440);

-- ----------------------------
-- Table structure for me_security_data_recycle_log
-- ----------------------------
DROP TABLE IF EXISTS `me_security_data_recycle_log`;
CREATE TABLE `me_security_data_recycle_log`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '操作管理员',
  `recycle_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '回收规则ID',
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '回收的数据',
  `data_table` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据表',
  `connection` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据库连接配置标识',
  `primary_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据表主键',
  `is_restore` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '是否已还原:0=否,1=是',
  `ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作者IP',
  `useragent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'User-Agent',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '数据回收记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_security_data_recycle_log
-- ----------------------------

-- ----------------------------
-- Table structure for me_security_sensitive_data
-- ----------------------------
DROP TABLE IF EXISTS `me_security_sensitive_data`;
CREATE TABLE `me_security_sensitive_data`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则名称',
  `controller` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '控制器',
  `controller_as` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '控制器别名',
  `data_table` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '对应数据表',
  `connection` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据库连接配置标识',
  `primary_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据表主键',
  `data_fields` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '敏感数据字段',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '状态:0=禁用,1=启用',
  `update_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '敏感数据规则表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_security_sensitive_data
-- ----------------------------
INSERT INTO `me_security_sensitive_data` VALUES (1, '管理员数据', 'auth/Admin.php', 'auth/admin', 'admin', '', 'id', '{\"username\":\"用户名\",\"mobile\":\"手机\",\"password\":\"密码\",\"status\":\"状态\"}', '1', 1712046440, 1712046440);
INSERT INTO `me_security_sensitive_data` VALUES (2, '会员数据', 'user/User.php', 'user/user', 'user', '', 'id', '{\"username\":\"用户名\",\"mobile\":\"手机号\",\"password\":\"密码\",\"status\":\"状态\",\"email\":\"邮箱地址\"}', '1', 1712046440, 1712046440);
INSERT INTO `me_security_sensitive_data` VALUES (3, '管理员权限', 'auth/Group.php', 'auth/group', 'admin_group', '', 'id', '{\"rules\":\"权限规则ID\"}', '1', 1712046440, 1712046440);

-- ----------------------------
-- Table structure for me_security_sensitive_data_log
-- ----------------------------
DROP TABLE IF EXISTS `me_security_sensitive_data_log`;
CREATE TABLE `me_security_sensitive_data_log`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '操作管理员',
  `sensitive_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '敏感数据规则ID',
  `data_table` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据表',
  `connection` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据库连接配置标识',
  `primary_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据表主键',
  `data_field` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '被修改字段',
  `data_comment` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '被修改项',
  `id_value` int(11) NOT NULL DEFAULT 0 COMMENT '被修改项主键值',
  `before` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '修改前',
  `after` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '修改后',
  `ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作者IP',
  `useragent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'User-Agent',
  `is_rollback` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '是否已回滚:0=否,1=是',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '敏感数据修改记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_security_sensitive_data_log
-- ----------------------------

-- ----------------------------
-- Table structure for me_test_build
-- ----------------------------
DROP TABLE IF EXISTS `me_test_build`;
CREATE TABLE `me_test_build`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `keyword_rows` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '关键词',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '内容',
  `views` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '浏览量',
  `likes` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '有帮助数',
  `dislikes` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '无帮助数',
  `note_textarea` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '状态:0=隐藏,1=正常',
  `weigh` int(11) NOT NULL DEFAULT 0 COMMENT '权重',
  `update_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '知识库表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_test_build
-- ----------------------------

-- ----------------------------
-- Table structure for me_token
-- ----------------------------
DROP TABLE IF EXISTS `me_token`;
CREATE TABLE `me_token`  (
  `token` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Token',
  `type` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '类型',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '用户ID',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  `expire_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`token`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '用户Token表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_token
-- ----------------------------

-- ----------------------------
-- Table structure for me_user
-- ----------------------------
DROP TABLE IF EXISTS `me_user`;
CREATE TABLE `me_user`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `group_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '分组ID',
  `username` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '昵称',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '邮箱',
  `mobile` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '手机',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '头像',
  `gender` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '性别:0=未知,1=男,2=女',
  `birthday` date NULL DEFAULT NULL COMMENT '生日',
  `money` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '余额',
  `score` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '积分',
  `last_login_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '上次登录时间',
  `last_login_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '上次登录IP',
  `login_failure` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '登录失败次数',
  `join_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '加入IP',
  `join_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '加入时间',
  `motto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '签名',
  `password` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
  `salt` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码盐',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '状态',
  `is_vip` tinyint(4) UNSIGNED NOT NULL DEFAULT 0 COMMENT '是否购买套裁:0=否,1=是',
  `vip_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '套餐到期时间',
  `vip_id` int(11) NULL DEFAULT 0 COMMENT '套餐ID',
  `user_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '' COMMENT '用户密钥',
  `update_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1000 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '会员表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_user
-- ----------------------------

-- ----------------------------
-- Table structure for me_user_basic
-- ----------------------------
DROP TABLE IF EXISTS `me_user_basic`;
CREATE TABLE `me_user_basic`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id',
  `uid` int(11) NULL DEFAULT NULL COMMENT '用户ID',
  `cash_desk_temp` int(1) NOT NULL DEFAULT 1 COMMENT '支付页面皮肤 ：\r\n1=classical 经典\r\n2=new 新版\r\n3=official 仿官方',
  `timeout_method` int(1) NOT NULL DEFAULT 1 COMMENT '超时跳转方式：1=原站 2=自定义',
  `timeout_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '超时自定义跳转地址',
  `timeout_time` int(5) NOT NULL DEFAULT 180 COMMENT '订单超时时间 默认 180秒',
  `alipay_jump` int(1) NOT NULL DEFAULT 1 COMMENT '支付宝跳转模式：\r\n1=with_remark - 带备注跳转模式\r\n2=no_remark - 无备注跳转模式\r\n3=enter_amount - 手动输入金额跳转模式\r\n4=locked_up - 锁死金额/订单号跳转模式',
  `cash_desk_tips` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '收银台提示',
  `floating_amount` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '收款浮动金额',
  `private_key` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '通讯密钥',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_user_basic
-- ----------------------------


-- ----------------------------
-- Table structure for me_user_group
-- ----------------------------
DROP TABLE IF EXISTS `me_user_group`;
CREATE TABLE `me_user_group`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '组名',
  `rules` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '权限节点',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '状态:0=禁用,1=启用',
  `update_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '会员组表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_user_group
-- ----------------------------
INSERT INTO `me_user_group` VALUES (1, '默认分组', '*', '1', 1712046440, 1712046440);

-- ----------------------------
-- Table structure for me_user_login_log
-- ----------------------------
DROP TABLE IF EXISTS `me_user_login_log`;
CREATE TABLE `me_user_login_log`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) NOT NULL COMMENT '商户ID',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '商户登录路由',
  `info` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '登录详情',
  `ip` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'IP',
  `login_time` int(11) NOT NULL COMMENT '登录时间戳',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_user_login_log
-- ----------------------------

-- ----------------------------
-- Table structure for me_user_money_log
-- ----------------------------
DROP TABLE IF EXISTS `me_user_money_log`;
CREATE TABLE `me_user_money_log`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '会员ID',
  `money` int(11) NOT NULL DEFAULT 0 COMMENT '变更余额',
  `before` int(11) NOT NULL DEFAULT 0 COMMENT '变更前余额',
  `after` int(11) NOT NULL DEFAULT 0 COMMENT '变更后余额',
  `memo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `type` int(1) NOT NULL DEFAULT 1 COMMENT '用户余额变动类型\r\n1：后台充值\r\n2：用户充值\r\n3：用户购买套餐',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '会员余额变动表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_user_money_log
-- ----------------------------

-- ----------------------------
-- Table structure for me_user_package
-- ----------------------------
DROP TABLE IF EXISTS `me_user_package`;
CREATE TABLE `me_user_package`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '套餐名称',
  `rate` decimal(5, 2) NOT NULL DEFAULT 0.00 COMMENT '套餐费率',
  `money` float(10, 2) NOT NULL DEFAULT 0.00 COMMENT '套餐价格',
  `time` int(10) NOT NULL DEFAULT 0 COMMENT '套餐时间',
  `weigh` int(10) NULL DEFAULT 0 COMMENT '权重',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '套餐状态:0=禁用,1=启用',
  `create_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '会员套餐表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_user_package
-- ----------------------------


-- ----------------------------
-- Table structure for me_user_rechange_order
-- ----------------------------
DROP TABLE IF EXISTS `me_user_rechange_order`;
CREATE TABLE `me_user_rechange_order`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id',
  `uid` int(11) NOT NULL COMMENT '用户ID',
  `trade_no` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '订单单号',
  `pay_type` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '支付类型:alipay=支付宝,wxpay=微信支付,qqpay=QQ支付',
  `money` float(10, 2) NOT NULL COMMENT '支付金额',
  `status` int(1) NOT NULL DEFAULT 0 COMMENT '订单状态:0=未支付,1=支付成功',
  `pay_time` bigint(20) NULL DEFAULT NULL COMMENT '支付时间',
  `create_time` bigint(20) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_user_rechange_order
-- ----------------------------

-- ----------------------------
-- Table structure for me_user_rule
-- ----------------------------
DROP TABLE IF EXISTS `me_user_rule`;
CREATE TABLE `me_user_rule`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '上级菜单',
  `type` enum('route','menu_dir','menu','nav_user_menu','nav','button') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'menu' COMMENT '类型:route=路由,menu_dir=菜单目录,menu=菜单项,nav_user_menu=顶栏会员菜单下拉项,nav=顶栏菜单项,button=页面按钮',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则名称',
  `path` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '路由路径',
  `icon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '图标',
  `menu_type` enum('tab','link','iframe') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'tab' COMMENT '菜单类型:tab=选项卡,link=链接,iframe=Iframe',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Url',
  `component` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '组件路径',
  `no_login_valid` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '未登录有效:0=否,1=是',
  `extend` enum('none','add_rules_only','add_menu_only') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none' COMMENT '扩展属性:none=无,add_rules_only=只添加为路由,add_menu_only=只添加为菜单',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `weigh` int(11) NOT NULL DEFAULT 0 COMMENT '权重',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '状态:0=禁用,1=启用',
  `update_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `pid`(`pid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '会员菜单权限规则表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_user_rule
-- ----------------------------
INSERT INTO `me_user_rule` VALUES (1, 0, 'menu_dir', '我的账户', 'account', 'account', 'fa fa-user-circle', 'tab', '', '', 0, 'none', '', 98, '1', 1712046440, 1712046440);
INSERT INTO `me_user_rule` VALUES (2, 1, 'menu', '账户概览', 'account/overview', 'account/overview', 'fa fa-home', 'tab', '', '/src/views/frontend/user/account/overview.vue', 0, 'none', '', 99, '1', 1712046440, 1712046440);
INSERT INTO `me_user_rule` VALUES (3, 1, 'menu', '个人资料', 'account/profile', 'account/profile', 'fa fa-user-circle-o', 'tab', '', '/src/views/frontend/user/account/profile.vue', 0, 'none', '', 98, '1', 1712046440, 1712046440);
INSERT INTO `me_user_rule` VALUES (4, 1, 'menu', '修改密码', 'account/changePassword', 'account/changePassword', 'fa fa-shield', 'tab', '', '/src/views/frontend/user/account/changePassword.vue', 0, 'none', '', 97, '1', 1712046440, 1712046440);
INSERT INTO `me_user_rule` VALUES (5, 1, 'menu', '积分记录', 'account/integral', 'account/integral', 'fa fa-tag', 'tab', '', '/src/views/frontend/user/account/integral.vue', 0, 'none', '', 96, '1', 1712046440, 1712046440);
INSERT INTO `me_user_rule` VALUES (6, 1, 'menu', '余额记录', 'account/balance', 'account/balance', 'fa fa-money', 'tab', '', '/src/views/frontend/user/account/balance.vue', 0, 'none', '', 95, '1', 1712046440, 1712046440);

-- ----------------------------
-- Table structure for me_user_score_log
-- ----------------------------
DROP TABLE IF EXISTS `me_user_score_log`;
CREATE TABLE `me_user_score_log`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '会员ID',
  `score` int(11) NOT NULL DEFAULT 0 COMMENT '变更积分',
  `before` int(11) NOT NULL DEFAULT 0 COMMENT '变更前积分',
  `after` int(11) NOT NULL DEFAULT 0 COMMENT '变更后积分',
  `memo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '会员积分变动表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_user_score_log
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
