<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV102 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {

        $group_config = \app\admin\model\Config::where('name', 'config_group')->find();
        $tmp          = $group_config->value;
        $tmp[]               = ['key' => "login_config", 'value' => "登录/注册"];
        $group_config->value = ($tmp);
        $group_config->save();

        $config_data = [
            [
                'name'      => 'registerd_config',
                'group'     => 'login_config',
                'title'     => '注册后跳转地址',
                'type'      => 'select',
                'value'     => 'login',
                'content'   => "login=登录页\r\nuserCenter=用户中心",
                'rule'      => 'required',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'pwd_check',
                'group'     => 'login_config',
                'title'     => '前台注册密码验证',
                'type'      => 'selects',
                'value'     => [
                    "2", "3", "4"
                ],
                'content'   => "1=无限制\r\n2=数字\r\n3=字母\r\n4=特殊字符",
                'rule'      => 'required',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'login_method',
                'group'     => 'login_config',
                'title'     => '登录注册方法',
                'type'      => 'select',
                'tips'      => '选择登录/注册的方式',
                'value'     => 'username',
                'content'   => "username=用户名\r\nemail=邮箱",
                'rule'      => 'required',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ]

        ];
        foreach ($config_data as $v){
            $model = new \app\admin\model\Config();
            $model->save($v);
        }

        try {
            $rule = \app\admin\model\AdminRule::where('id',148)->find();
            $rule->title = '账户管理';
            $rule->save();
        }catch (Exception $e){
            
        }
        $this->execute("ALTER TABLE `me_cloud` MODIFY COLUMN `type` enum('wxpay','qqpay') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'wxpay' COMMENT '类型:wxpay=微信,qqpay=QQ' AFTER `cloud_type`;");

        $this->execute("INSERT INTO `me_admin_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (168, 0, 'menu_dir', '邮件发送管理', 'mail', 'mail', 'el-icon-Message', 'tab', '', '', 0, 'none', '', 0, '1', 1713325345, 1713325345);
INSERT INTO `me_admin_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (169, 168, 'menu', '模板管理', 'mail/template', 'mail/template', 'el-icon-Document', 'tab', '', '/src/views/backend/mail/template/index.vue', 0, 'none', '', 0, '1', 1713326120, 1713325345);
INSERT INTO `me_admin_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (170, 169, 'button', '查看', 'mail/template/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1713325345, 1713325345);
INSERT INTO `me_admin_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (171, 169, 'button', '添加', 'mail/template/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1713325345, 1713325345);
INSERT INTO `me_admin_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (172, 169, 'button', '编辑', 'mail/template/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1713325345, 1713325345);
INSERT INTO `me_admin_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (173, 169, 'button', '删除', 'mail/template/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1713325345, 1713325345);
");
        $this->execute("CREATE TABLE `me_mail_template`  (
  `id` int(3) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '邮件标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '邮件内容',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '状态:0=禁用,1=启用',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `update_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '修改时间',
  `create_time` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '邮件模板管理' ROW_FORMAT = Dynamic;");
        $this->execute("INSERT INTO `me_mail_template` VALUES (1, 'forgot', '找回密码', '正在找回密码，验证码{code}', 1, '', 1713327577, 1713326198);");
        $this->execute("INSERT INTO `me_channel_type`( `name`, `type`, `code`, `status`, `remark`, `create_time`, `update_time`) VALUES ('微信云端', 'wxpay', 'wxpay_cloud', 1, '', 1712486942, 1712486942);
");

    }
}
