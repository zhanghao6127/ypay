<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV104 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $group_config = \app\admin\model\Config::where('name', 'config_group')->find();
        $tmp          = $group_config->value;
        $tmp[]               = ['key' => "privacy_config", 'value' => "协议配置"];
        $group_config->value = ($tmp);
        $group_config->save();
        $config_data = [
            [
                'name'      => 'user_agreement_config',
                'group'     => 'privacy_config',
                'title'     => '用户协议',
                'type'      => 'editor',
                'value'     => '',
                'content'   => "",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'privacy_policy_config',
                'group'     => 'privacy_config',
                'title'     => '隐私协议',
                'type'      => 'editor',
                'value'     => '',
                'content'   => "",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
        ];

        $config = new \app\admin\model\Config();
        $config->saveAll($config_data);

        // 修改了通道key   修改type表和通道表
        \app\common\model\channel\Type::where('code' ,'alipay_dmf')->update(['code'=>'alipay_scan']);
        \app\common\model\channel\Type::where('code','alipay_grmg')->update(['code'=>'alipay_person']);

        \app\common\model\channel\Account::where('key','alipay_dmf')->update(['key'=>'alipay_scan']);
        \app\common\model\channel\Account::where('key','alipay_grmg')->update(['key'=>'alipay_person']);
        $config = null;
        $config = new \app\admin\model\Config();
        $config = $config->where('name','version')->find();
        if (!empty($config)){
            $config->value = 'V1.0.4';
            $config->save();
        }
    }
}
