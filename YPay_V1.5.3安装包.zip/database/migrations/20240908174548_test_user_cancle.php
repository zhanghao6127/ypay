<?php

use think\migration\Migrator;
use think\migration\db\Column;

class TestUserCancle extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {

        $configModel = new \app\admin\model\Config();
        $userCancle = $configModel->where('name', 'user_cancle')->find();
        if (empty($userCancle)){
            $configModel->save([
                'name'        => 'user_cancle',
                'group'       => 'member_config',
                'title'       => '会员注销开关',
                'tip'         => '',
                'type'        => 'radio',
                'value'       => 0,
                'content'     => "0=关闭\r\n1=开启",
                'rule'        => '',
                'allow_del'   => 0,
                'extend' => '',
                'weigh'      => 0,
                'inputExtend' => '',
            ]);
        }
    }
}
