<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV109 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        \app\admin\model\AdminRule::where('title', '邮件发送管理')->update(['title' => '邮箱管理']);

        $this->execute("ALTER TABLE `me_user_rule` 
MODIFY COLUMN `icon` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图标' AFTER `path`");
        $configModel = new \app\admin\model\Config();
        $configModel->where('group','pay_config')->delete();
        $group_config  = $configModel->where('name','config_group')->find();
        $tmp_group = [];
        foreach ($group_config->value as $k=>$v){
            if ($v['key'] != 'pay_config'){
                $tmp_group[] = [
                    'key' => $v['key'],
                    'value' => $v['value']
                ];
            }
        }
        $group_config->value = $tmp_group;
        $group_config->save();

        $tmp_data  = [
            [
                'name'        => 'alipay',
                'group'       => 'pay_config',
                'title'       => '支付宝支付',
                'tip'         => '',
                'type'        => 'string',
                'value'       => 1,
                'content'     => "1=开启\r\n0=关闭",
                'rule'        => '',
                'allow_del'   => 1,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'qqpay',
                'group'       => 'pay_config',
                'title'       => 'QQ支付',
                'tip'         => '',
                'type'        => 'string',
                'value'       => 1,
                'content'     => "1=开启\r\n0=关闭",
                'rule'        => '',
                'allow_del'   => 1,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'wxpay',
                'group'       => 'pay_config',
                'title'       => '微信支付',
                'tip'         => '',
                'type'        => 'string',
                'value'       => 1,
                'content'     => "1=开启\r\n0=关闭",
                'rule'        => '',
                'allow_del'   => 1,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'pay_card',
                'group'       => 'pay_config',
                'title'       => '卡密支付',
                'tip'         => '',
                'type'        => 'string',
                'value'       => 1,
                'content'     => "1=开启\r\n0=关闭",
                'rule'        => '',
                'allow_del'   => 1,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'buy_card_url',
                'group'       => 'pay_config',
                'title'       => '卡密购买地址',
                'tip'         => '',
                'type'        => 'string',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 1,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
        ];
        $configModel->saveAll($tmp_data);

        $this->execute("ALTER TABLE `me_cloud` 
MODIFY COLUMN `cloud_type` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '云端类型:1=V1,2=V2,3=V3,4=PC' AFTER `status`");
        $this->execute("ALTER TABLE `me_cloud` 
ADD COLUMN `qrcode` varchar(255) NULL DEFAULT '' COMMENT '二维码信息' AFTER `weigh`");
        $this->execute("CREATE TABLE `me_oauth`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `key` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT 'qq:qq wx:微信扫码',
  `type` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'official:官方 aggregated：聚合登录',
  `app_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'appid',
  `app_secret` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '密钥',
  `callback_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '回调地址',
  `agg_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '聚合登录ID',
  `agg_key` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '聚合登录ey',
  `agg_address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '聚合登录接口地址',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_oauth
-- ----------------------------
INSERT INTO `me_oauth` VALUES (1, 'qq', 'official', '', '', '/api/OAuthLogin/notify', '', '', '');
INSERT INTO `me_oauth` VALUES (2, 'wx', 'official', '', '', '/api/OauthLogin/notify', '', '', '');");

        $this->execute("CREATE TABLE `me_pay_channel`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '通道名称',
  `type` enum('alipay','wxpay','qqpay') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'alipay' COMMENT ' 支付类型 alipay：支付宝 wxpay：微信 qqpay：QQ',
  `pay_type` enum('official','ypay','') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'official' COMMENT '通道支付类型  official：官方 ypay：易支付',
  `appid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'APPID',
  `public_key` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '公钥',
  `private_key` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '私钥',
  `mch_id` int(11) NOT NULL DEFAULT 0 COMMENT '商户号',
  `pay_address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '支付地址',
  `secret` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '密钥',
  `weigh` int(11) NULL DEFAULT 0 COMMENT '权重',
  `sum_money` int(11) NOT NULL DEFAULT 0 COMMENT '累计收款',
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '状态 0：关闭 1：开启',
  `create_time` bigint(20) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '充值支付配置表' ROW_FORMAT = Dynamic;");
        $this->execute("ALTER TABLE `me_oauth_log` 
MODIFY COLUMN `source` enum('qq','wx') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'qq' COMMENT '来源:qq=腾讯QQ,wx=微信扫码' AFTER `user_id`");
        $menuid  = \app\admin\model\AdminRule::where('title','常规管理')->find();
        if (empty($menuid)) $menuid = 44;
        $this->execute("INSERT INTO `me_admin_rule`( `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES ({$menuid['id']}, 'menu', '支付配置', 'pay_config', '', 'el-icon-Operation', 'tab', '', '/src/views/backend/routine/payment/index.vue', 0, 'none', '', 0, '1', 1715615264, 1715615159);
");
        $this->execute("INSERT INTO `me_channel_type`(`name`, `type`, `code`, `status`, `remark`, `create_time`, `update_time`) VALUES ('微信软件版', 'wxpay', 'wxpay_software', 1, '', 1712486942, 1712486942);
INSERT INTO `me_channel_type`(`name`, `type`, `code`, `status`, `remark`, `create_time`, `update_time`) VALUES ('支付宝软件版', 'alipay', 'alipay_software', 1, '', 1712486942, 1712486942);
INSERT INTO `me_channel_type`(`name`, `type`, `code`, `status`, `remark`, `create_time`, `update_time`) VALUES ('QQ软件版', 'qqpay', 'qqpay_software', 1, '', 1712486942, 1712486942);
");
        \app\admin\model\AdminRule::where('title','卡密管理')->delete();
        \app\admin\model\AdminRule::where('title','邮件配置')->update(['weigh' => 99,'icon'=>'el-icon-Setting']);
        $config = \app\admin\model\Config::where('name','version')->find();
        if (!empty($config)){
            $config->value = 'V1.1.0';
            $config->save();
        }
    }
}
