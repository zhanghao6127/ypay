<?php

use app\admin\model\AdminRule;
use app\common\library\Menu;
use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV152 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $configModel = new \app\admin\model\Config();
        $configModel->save([
            'name'        => 'wxpusher_switch',
            'group'       => 'wechat_config',
            'title'       => 'WxPusher',
            'tip'         => '',
            'type'        => 'radio',
            'value'       => 0,
            'content'     => "0=关闭\r\n1=开启",
            'rule'        => '',
            'allow_del'   => 0,
            'extend' => '',
            'weigh'      => 99,
            'inputExtend' => '',
        ]);

        $wechatMenu = \app\admin\model\AdminRule::where('name','wxpusher')->find();
        if ($wechatMenu){
            $wechatMenu->name='wechat';
            $wechatMenu->icon = 'fa fa-wechat';
            $wechatMenu->save();
        }

        $group_config = $configModel->where('name', 'config_group')->find();
        $tmp = $group_config->value;
        $newTmp = [];
        foreach ($tmp as $v){
            if ($v['key'] != 'wechat_config'){
                $newTmp[] = $v;
            }
        }
        $group_config->value = $newTmp;
        $group_config->save();

        $pMenu = AdminRule::where('name', 'wechat')->value('id');

        $menuData = [
            ['type' => 'menu', 'title' => 'wxPusher配置', 'name' => 'wechat/setwxPusher', 'path' => 'wechat/setwxPusher','icon'=>'fa fa-circle-o', 'menu_type'=>'tab','component'=>'/src/views/backend/wxpusher/setwxPusher/index.vue','keepalive'=>1,'status' => 1, 'pid' => $pMenu,]
        ];
        Menu::create($menuData);

        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.5.2';
            $config->save();
        }
    }
}
