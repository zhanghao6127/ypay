<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV114 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversibl e migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $config = \app\admin\model\Config::where('name','version')->find();
        if (!empty($config)){
            $config->value = 'V1.1.4';
            $config->save();
        }

        $data  = [
            'name'        => 'register_method',
            'group'       => 'login_config',
            'title'       => '注册验证方法',
            'tip'         => '',
            'type'        => 'selects',
            'value'       => ["username","email"],
            'content'     => "username=用户名\r\nemail=邮箱\r\nmobile=手机号",
            'rule'        => 'required',
            'allow_del'   => 0,
            'weigh'       => 0,
            'extend'      => '',
            'inputExtend' => '',
        ];
        $model = new \app\admin\model\Config();
        $res = $model->save($data);


        $model->where('name','login_method')->update([
            'title' => '登录验证方法'
        ]);
    }
}
