<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV146 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $this->execute("ALTER TABLE `me_card`
ADD COLUMN `type` int(1) NOT NULL DEFAULT 1 COMMENT '1:加款卡 2：会员套餐' AFTER `user_id`,
ADD COLUMN `package_id` int NOT NULL DEFAULT 0 COMMENT '套餐ID' AFTER `type`");

        $this->execute("CREATE TABLE `me_user_register_pay`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `trade_no` varchar(50) NOT NULL COMMENT '订单号',
  `out_trade_no` varchar(50) NOT NULL DEFAULT '' COMMENT '外部订单号',
  `price` decimal(10, 2) NULL DEFAULT 0 COMMENT '订单金额',
  `status` int(1) NOT NULL COMMENT '订单状态 1：未支付 2：已支付',
  `pay_time` int(11) NULL COMMENT '支付时间',
  `uid` int NOT NULL DEFAULT 0 COMMENT '用户ID 默认0 支付成功注册后会更新',
  `create_time` int(11) NULL COMMENT '创建时间',
  `update_time` int(11) NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
)");
        $this->execute("ALTER TABLE `me_user_register_pay`
ADD COLUMN `channel_id` int NOT NULL COMMENT '通道ID' AFTER `id`");

        $this->execute("ALTER TABLE `me_user_register_pay`
ADD COLUMN `register_data` text NULL COMMENT '用户注册信息' AFTER `uid`");
        $this->execute("ALTER TABLE `me_user_register_pay`
MODIFY COLUMN `channel_id` int(11) NOT NULL DEFAULT 0 COMMENT '通道ID' AFTER `id`,
MODIFY COLUMN `status` int(1) NOT NULL DEFAULT 0 COMMENT '订单状态 1：未支付 2：已支付' AFTER `price`");

        $configModel = new \app\admin\model\Config();
        $group_config = $configModel->where('name', 'config_group')->find();
        $tmp = $group_config->value;
        $tmp[] = ['key' => "member_config", 'value' => "会员配置"];
        $group_config->value = $tmp;
        $group_config->save();

        $data = [
            [
                'name'        => 'member_default_avatar',
                'group'       => 'member_config',
                'title'       => '默认头像',
                'tip'         => '',
                'type'        => 'image',
                'value'       => '/static/images/avatar.png',
                'content'     => "",
                'rule'        => '',
                'extend' => '',
                'allow_del'   => 0,
                'weigh'      => 0,
                'inputExtend' => '',

            ],
            [
                'name'        => 'member_register_pay',
                'group'       => 'member_config',
                'title'       => '会员付费注册',
                'tip'         => '',
                'type'        => 'radio',
                'value'       => 0,
                'content'     => "0=关闭\r\n1=开启",
                'rule'        => '',
                'allow_del'   => 0,
                'extend' => '',
                'weigh'      => 0,
                'inputExtend' => '',

            ],
            [
                'name'        => 'member_register_money',
                'group'       => 'member_config',
                'title'       => '会员付费注册金额',
                'tip'         => '',
                'type'        => 'string',
                'value'       => 0.01,
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'      => 0,
                'extend' => '',
                'inputExtend' => '',

            ]
        ];
        $configModel->saveAll($data);

        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.4.6';
            $config->save();
        }
    }
}
