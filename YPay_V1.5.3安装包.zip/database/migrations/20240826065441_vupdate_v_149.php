<?php

use think\migration\Migrator;
use think\migration\db\Column;

class VupdateV149 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $this->execute("ALTER TABLE `me_user_package` 
ADD COLUMN `channel_limit` int(1) NOT NULL DEFAULT 0 COMMENT '通道限制开关 0：关闭 1：开启' AFTER `package_introduce`,
ADD COLUMN `channel_limit_num` int NOT NULL DEFAULT 0 COMMENT '通道限制数量' AFTER `channel_limit`");
        $configModel = new \app\admin\model\Config();
        $data = [
            [
                'name'        => 'pay_proclamation',
                'group'       => 'proclamation_config',
                'title'       => '支付页面公告',
                'tip'         => '',
                'type'        => 'editor',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'extend' => '',
                'allow_del'   => 0,
                'weigh'      => 0,
                'inputExtend' => '',

            ],
            [
                'name'        => 'pay_proclamation_open',
                'group'       => 'proclamation_config',
                'title'       => '支付页面弹窗',
                'tip'         => '',
                'type'        => 'radio',
                'value'       => 0,
                'content'     => "0=关闭\r\n1=开启",
                'rule'        => '',
                'allow_del'   => 0,
                'extend' => '',
                'weigh'      => 0,
                'inputExtend' => '',

            ],
            [
                'name'        => 'register_pay_channel_qqpay',
                'group'       => 'login_config',
                'title'       => 'QQ',
                'tip'         => '',
                'type'        => 'remoteSelect',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'      => 0,
                'extend' => '',
                'inputExtend' => '',

            ],
            [
                'name'        => 'register_pay_channel_wxpay',
                'group'       => 'login_config',
                'title'       => '微信',
                'tip'         => '',
                'type'        => 'remoteSelect',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'      => 0,
                'extend' => '',
                'inputExtend' => '',

            ],
            [
                'name'        => 'register_pay_channel_alipay',
                'group'       => 'login_config',
                'title'       => '支付宝',
                'tip'         => '',
                'type'        => 'remoteSelect',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'      => 0,
                'extend' => '',
                'inputExtend' => '',

            ],
        ];
        $configModel->saveAll($data);

        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.4.9';
            $config->save();
        }
    }
}
