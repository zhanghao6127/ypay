<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV108 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $config = \app\admin\model\Config::where('name','version')->find();
        if (!empty($config)){
            $config->value = 'V1.0.8';
            $config->save();
        }

        $data  = [
            'name'        => 'buy_card_url',
            'group'       => 'pay_config',
            'title'       => '卡密购买地址',
            'tip'         => '不想用自己网站支付可以用卡密规避风险，自己生产充值卡密去第三方平台，用户购买卡密后回来充值消费',
            'type'        => 'string',
            'value'       => '',
            'content'     => "",
            'rule'        => '',
            'allow_del'   => 1,
            'weigh'       => 0,
            'extend'      => '',
            'inputExtend' => '',
        ];
        $model = new \app\admin\model\Config();
        $model->save($data);
        $tmp_data  = [
            'name'        => 'smtp_sender_name',
            'group'       => 'mail',
            'title'       => '发件人名称',
            'tip'         => '',
            'type'        => 'string',
            'value'       => '',
            'content'     => "",
            'rule'        => '',
            'allow_del'   => 1,
            'weigh'       => 0,
            'extend'      => '',
            'inputExtend' => '',
        ];
        $model->save($tmp_data);

        \app\admin\model\AdminRule::where('title', '第三方授权登录')->update(['title' => '快捷登录']);
        \app\admin\model\AdminRule::where('title', '三方平台配置')->update(['title' => '快捷登录配置']);
        \app\admin\model\Config::where('name', 'record_number')->update(['title' => '底部版权信息']);
        \app\admin\model\UserRule::where('title', '通道列表')->update(['weigh' => 16]);

        \app\admin\model\sms\Template::where('code', 'user_change_mobile')->update(['variables' => 1]);
        $id = \app\admin\model\sms\Variable::where('name', 'code')->find();
        \app\admin\model\sms\Template::where('status', 1)->update(['variables' => $id['id'] ?? 1]);

        $pwd_check = $model->where('name','pwd_check')->find();
        if (!empty($pwd_check->value)){
            $tmp_pwd_check = $pwd_check->value;
            foreach ($tmp_pwd_check as $k=>$v){
                if (is_numeric($v)){
                    $tmp_pwd_check[$k] = (string)$v;
                }
            }
            $pwd_check->value = $tmp_pwd_check;
            $pwd_check->save();
        }

        $username_check = $model->where('name','username_check')->find();
        if (!empty($username_check->value)){
            $tmp_username_check = $username_check->value;
            foreach ($tmp_username_check as $k=>$v){
                if (is_numeric($v)){
                    $tmp_username_check[$k] = (string)$v;
                }
            }
            $username_check->value = $tmp_username_check;
            $username_check->save();
        }

        $group = $model->where('name','config_group')->find();
        $tmp_group = [];
        foreach ($group->value as $k=>$v){
            if ($v['key'] != 'config_quick_entrance' && $v['key'] != 'mail'){
                $tmp_group[] = [
                    'key' => $v['key'],
                    'value' => $v['value']
                ];
            }
        }
        $tmp_group[]=[
            'key' => 'config_quick_entrance',
            'value' => 'Config Quick entrance',
        ];
        $group->value = $tmp_group;
        $group->save();

        $pid = \app\admin\model\AdminRule::where('name','mail')->find();
        if (!empty($pid->id)){
            $this->execute("INSERT INTO `me_admin_rule`( `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES ({$pid->id}, 'menu', '邮件配置', 'mail/emailtab', 'mail/emailtab', 'fa fa-circle-o', 'tab', '', '/src/views/backend/mail/emailtab/index.vue', 1, 'none', '', 0, '1', 1715075219, 1715073307);");
        }

        $this->execute("INSERT INTO `me_sms_template`(`title`, `code`, `template`, `content`, `variables`, `status`, `updatetime`, `createtime`) VALUES ( '用户解绑手机号', 'user_unbind_mobile', '', '', '{$id['id']}', 1, 1715069957, 1715058804);");
        $this->execute("INSERT INTO `me_mail_template`(`name`, `title`, `content`, `status`, `remark`, `update_time`, `create_time`) VALUES ('bind', '邮箱绑定', 'Ypay邮箱绑定验证码：{code}', 1, '', 1715068860, 1715068860);");

        $this->execute("INSERT INTO `me_mail_template`( `name`, `title`, `content`, `status`, `remark`, `update_time`, `create_time`) VALUES ('unbind', '解绑邮箱', 'Ypay邮箱解绑验证码：{code}', 1, '', 1715069390, 1715069369);");
    }
}
