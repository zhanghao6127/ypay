<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV140 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $this->execute("ALTER TABLE `me_user_package` 
ADD COLUMN `recomme` int(1) NOT NULL DEFAULT 0 COMMENT '是否推荐 0：不推荐 1：推荐' AFTER `background_deg`");

        $this->execute("ALTER TABLE `me_user_package` 
ADD COLUMN `content_font_color` varchar(20) NOT NULL DEFAULT '' COMMENT '内容文字颜色' AFTER `recomme`");

        $this->execute("ALTER TABLE `me_user` 
ADD COLUMN `google_auth_secret` varchar(255) NOT NULL DEFAULT '' COMMENT '谷歌验证器密钥' AFTER `rate`");

        $this->execute("ALTER TABLE `me_user_basic` 
ADD COLUMN `new_order` int(1) NOT NULL DEFAULT 0 COMMENT '新订单通知' AFTER `balance_notice_price`	");

        $this->execute("INSERT INTO `me_mail_template`( `name`, `title`, `content`, `status`, `remark`, `update_time`, `create_time`) VALUES ( 'new_order', '新订单通知', '用户有新的订单，订单号：{order_no},订单金额：{money}', 1, '', 1719087415, 1719087415);");

        $this->execute("CREATE TABLE `me_guid`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `url` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `qr_url` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `skey` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `sid` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `uin` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `pass_ticket` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `cookies` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `key` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `key2` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `name` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `uid` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',
  `time` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;
");
        $configModel = new \app\admin\model\Config();
        $data = [
            [
                'name'        => 'open_index_security',
                'group'       => 'security_config',
                'title'       => '前台安全校验',
                'tip'         => '',
                'type'        => 'radio',
                'value'       => '0',
                'content'     => "0=关闭\r\n1=开启",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'security_index_name',
                'group'       => 'security_config',
                'title'       => '展示名称',
                'tip'         => '',
                'type'        => 'string',
                'value'       => '谷歌',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'security_index_icon',
                'group'       => 'security_config',
                'title'       => '展示图标',
                'tip'         => '',
                'type'        => 'image',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'security_index_tips',
                'group'       => 'security_config',
                'title'       => '绑定框提示',
                'tip'         => '',
                'type'        => 'textarea',
                'value'       => '通过微信小程序搜索谷歌验证器进行扫码',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'force_security',
                'group'       => 'security_config',
                'title'       => '是否强制用户绑定',
                'tip'         => '',
                'type'        => 'radio',
                'value'       => '0',
                'content'     => "0=关闭\r\n1=开启",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
        ];
        $configModel->saveAll($data);

        $group_config = $configModel->where('name', 'config_group')->find();
        $tmp = $group_config->value;
        $tmp[] = ['key' => "security_config", 'value' => "安全校验"];
        $group_config->value = $tmp;
        $group_config->save();


        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.4.0';
            $config->save();
        }
    }
}
