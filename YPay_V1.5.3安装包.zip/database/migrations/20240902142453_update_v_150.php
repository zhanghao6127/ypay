<?php

use app\admin\model\AdminRule;
use app\common\library\Menu;
use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV150 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $configModel = new \app\admin\model\Config();
        // 用户注销
        $this->execute("ALTER TABLE `me_user` 
ADD COLUMN `cancle_status` int(1) NOT NULL DEFAULT 1 COMMENT '用户注销状态 1：正常 2：申请注销' AFTER `google_auth_secret`");

        $configModel->save([
            'name'        => 'user_cancle',
            'group'       => 'member_config',
            'title'       => '会员注销开关',
            'tip'         => '',
            'type'        => 'radio',
            'value'       => 0,
            'content'     => "0=关闭\r\n1=开启",
            'rule'        => '',
            'allow_del'   => 0,
            'extend' => '',
            'weigh'      => 0,
            'inputExtend' => '',
        ]);
        // 添加禁用原因
        $this->execute("ALTER TABLE `me_user` 
ADD COLUMN `jyly` text NOT NULL COMMENT '禁用原因' AFTER `cancle_status`");

        // 套餐通道支付类型
        $this->execute("ALTER TABLE `me_user_package` 
ADD COLUMN `channnel_type_limit` int(1) NOT NULL DEFAULT 0 COMMENT '通道支付类型限制开关 0：关闭 1：开启' AFTER `channel_limit_num`,
ADD COLUMN `channel_type_list` varchar(255) NOT NULL DEFAULT '' COMMENT '通道支付类型列表' AFTER `channnel_type_limit`");

        // wxpusher
        $this->execute("ALTER TABLE `me_user` 
ADD COLUMN `wxpusher_uid` varchar(50) NOT NULL DEFAULT '' COMMENT 'wxpusher UID' AFTER `jyly`");
        $this->execute("DROP TABLE IF EXISTS `me_wxpusher_template`;
CREATE TABLE `me_wxpusher_template`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '内容',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '状态:0=禁用,1=启用',
  `remark` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `update_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '修改时间',
  `create_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'wxpusher模板' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_wxpusher_template
-- ----------------------------
INSERT INTO `me_wxpusher_template` VALUES (1, 'login_notice', '', 1, '登录通知', 1725722099, 1725714458);
INSERT INTO `me_wxpusher_template` VALUES (2, 'offlineline_account_notice', '', 1, '通道下线', 1725722099, 1725714458);
INSERT INTO `me_wxpusher_template` VALUES (3, 'order_notice', '', 1, '订单收款', 1725722099, 1725714458);
INSERT INTO `me_wxpusher_template` VALUES (4, 'balance_notice', '', 1, '余额不足', 1725722099, 1725714458);
INSERT INTO `me_wxpusher_template` VALUES (5, 'new_order', '', 1, '新订单', 1725722099, 1725714458);");
        $group_config = $configModel->where('name', 'config_group')->find();
        $tmp = $group_config->value;
            $tmp[] = ['key' => "wechat_config", 'value' => "微信配置"];
        $group_config->value = $tmp;
        $group_config->save();
        $configModel->save([
            'name'        => 'wxpusher_open',
            'group'       => 'wechat_config',
            'title'       => '开启wxPusher',
            'tip'         => '',
            'type'        => 'radio',
            'value'       => 0,
            'content'     => "0=关闭\r\n1=开启",
            'rule'        => '',
            'allow_del'   => 0,
            'extend' => '',
            'weigh'      => 0,
            'inputExtend' => '',
        ]);
        $configModel->save([
            'name'        => 'wxpusher_token',
            'group'       => 'wechat_config',
            'title'       => 'WxPusherToken',
            'tip'         => 'wxPusher token 回调地址  域名+/api/wxPusherCallback?server=1',
            'type'        => 'string',
            'value'       => '',
            'content'     => "",
            'rule'        => '',
            'allow_del'   => 0,
            'extend' => '',
            'weigh'      => 0,
            'inputExtend' => '',
        ]);

        // 菜单
        $pMenu = AdminRule::where('name', 'routine')->value('id');
        if ($pMenu) {
            $menuData = [
                ['type' => 'menu_dir', 'title' => '微信设置', 'name' => 'wxpusher', 'path' => 'wxpusher', 'status' => 1, 'pid' => $pMenu,],
                ['type' => 'menu', 'title' => '数据清理', 'name' => 'cleandata', 'path' => 'routine/dataClear','icon'=>'el-icon-Setting', 'menu_type'=>'tab','component'=>'/src/views/backend/routine/dataClear/index.vue','keepalive'=>1,'status' => 1, 'pid' => $pMenu,]
            ];
            Menu::create($menuData);
            $pMenu = AdminRule::where('name', 'wxpusher')->value('id');
            $menuData = [
                ['type' => 'menu', 'title' => 'wxpusher模板', 'name' => 'wxpusher/template', 'path' => 'wxpusher/template', 'menu_type'=>'tab','component'=>'/src/views/backend/wxpusher/template/index.vue','keepalive'=>1,'status' => 1, 'pid' => $pMenu,]
            ];
            Menu::create($menuData);
            $pMenu = AdminRule::where('name', 'wxpusher/template')->value('id');
            $menu = [
                ['type' => 'button', 'title' => '查看', 'name' => 'wxpusher/template/index', 'pid' => $pMenu,],
                ['type' => 'button', 'title' => '添加', 'name' => 'wxpusher/template/add', 'pid' => $pMenu,],
                ['type' => 'button', 'title' => '编辑', 'name' => 'wxpusher/template/edit', 'pid' => $pMenu,],
                ['type' => 'button', 'title' => '删除', 'name' => 'wxpusher/template/del', 'pid' => $pMenu,],
                ['type' => 'button', 'title' => '快速排序', 'name' => 'wxpusher/template/sortable', 'pid' => $pMenu,],
            ];
            Menu::create($menu);
        }
    }
}
