<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV131 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $configModel = new \app\admin\model\Config();
        $data =[
            'name'        => 'mail_switch',
            'group'       => 'mail',
            'title'       => '邮箱发送开关',
            'tip'         => '',
            'type'        => 'number',
            'value'       => '0',
            'content'     => "",
            'rule'        => '',
            'allow_del'   => 0,
            'weigh'       => 0,
            'extend'      => '',
            'inputExtend' => '',
        ];
        $configModel->save($data);

        $this->execute("INSERT INTO `me_mail_template`( `name`, `title`, `content`, `status`, `remark`, `update_time`, `create_time`) VALUES ('vip_end', '用户会员到期', '用户会员到期，请及时购买', 1, '', 1718317612, 1718317612);
");
        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.3.1';
            $config->save();
        }
    }
}
