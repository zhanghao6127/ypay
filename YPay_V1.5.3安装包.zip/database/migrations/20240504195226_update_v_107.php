<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV107 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $config = \app\admin\model\Config::where('name','version')->find();
        if (!empty($config)){
            $config->value = 'V1.0.7';
            $config->save();
        }

        $this->execute("INSERT INTO `me_channel_type`(`name`, `type`, `code`, `status`, `remark`, `create_time`, `update_time`) VALUES ('QQ免挂', 'qqpay', 'qqpay_person', 1, '', 1712486942, 1712486942);
");
        $this->execute("ALTER TABLE `me_user` 
ADD COLUMN `rate` int NOT NULL DEFAULT 0 COMMENT '用户费率' AFTER `user_key`");

        $data =             [
            'name'      => 'use_card_rechange',
            'group'     => 'pay_config',
            'title'     => '是否开启卡密充值',
            'type'      => 'radio',
            'value'     => '1',
            'content'   => "0=关闭\r\n1=开启",
            'rule'      => '',
            'allow_del' => 1,
            'weigh'     => 0,
            'extend'     => '',
            'inputExtend'     => '',
        ];
        $model = new \app\admin\model\Config();
        $model->save($data);

    }
}
