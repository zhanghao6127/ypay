<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV147 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $configModel = new \app\admin\model\Config();
        $configModel->where('name','member_register_pay')->update(['group' => 'login_config']);
        $configModel->where('name','member_register_money')->update(['group' => 'login_config']);
        $configModel->save([
            'name'        => 'close_register',
            'group'       => 'login_config',
            'title'       => '关闭注册',
            'tip'         => '',
            'type'        => 'radio',
            'value'       => 0,
            'content'     => "0=关闭\r\n1=开启",
            'rule'        => '',
            'allow_del'   => 0,
            'extend' => '',
            'weigh'      => 0,
            'inputExtend' => '',

        ]);
        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.4.7';
            $config->save();
        }
    }
}
