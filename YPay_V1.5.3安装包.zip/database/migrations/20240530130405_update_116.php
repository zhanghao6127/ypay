<?php

use think\migration\Migrator;
use think\migration\db\Column;

class Update116 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.1.6';
            $config->save();
        }

        $this->execute("ALTER TABLE `me_user_package` 
ADD COLUMN `background_deg` varchar(20) NOT NULL DEFAULT 0 COMMENT '角度轴' AFTER `botton_font_color`");

        $data = [
            [
                'name'        => 'site_keywords',
                'group'       => 'basics',
                'title'       => '网站关键字',
                'tip'         => '',
                'type'        => 'string',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'site_details',
                'group'       => 'basics',
                'title'       => '网站详情',
                'tip'         => '',
                'type'        => 'textarea',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ]
        ];
        $configModel = new \app\admin\model\Config();
        $configModel->saveAll($data);

        $configModel->where('name','index_jump_method')->update([
            'title' => '首页开关',
            'weigh' => 96,
        ]);
        $configModel->where('name','site_keywords')->update([
            'weigh' => 95,
        ]);
        $configModel->where('name','site_details')->update([
            'weigh' => 94,
        ]);
        $userRule = new \app\admin\model\UserRule();
        $tmp = $userRule->where('id',15)->find();
        if (!empty($tmp)){
            $tmp->title = '通道配置';
            $tmp->name = 'apps-system-channel-channel-set';
            $tmp->path = 'apps-system-channel-channel-set';
            $tmp->save();
        }
    }
}
