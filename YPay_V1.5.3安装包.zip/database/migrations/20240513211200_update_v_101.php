<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV101 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $data  = [
            'name'        => 'record_html',
            'group'       => 'basics',
            'title'       => '底部版权代码',
            'tip'         => '',
            'type'        => 'textarea',
            'value'       => '',
            'content'     => "",
            'rule'        => '',
            'allow_del'   => 0,
            'weigh'       => 0,
            'extend'      => '',
            'inputExtend' => '',
        ];
        $model = new \app\admin\model\Config();
        $model->save($data);

        $this->execute("ALTER TABLE `me_user_rechange_order` 
ADD COLUMN `channel_id` int NOT NULL DEFAULT 0 COMMENT '通道ID' AFTER `uid`");

        $this->execute("ALTER TABLE `me_user` 
MODIFY COLUMN `rate` float(11, 2) NOT NULL DEFAULT 0 COMMENT '用户费率' AFTER `user_key`");

        \app\admin\model\AdminRule::where('id',174)->delete();
        
        $this->execute("UPDATE `me_user_rule` SET `pid` = 0, `type` = 'route', `title` = '仪表盘', `name` = 'dashboards-analytics', `path` = 'dashboards-analytics', `icon` = 'dashboard', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 16, `status` = '1', `update_time` = 1715653351, `create_time` = 1714222152 WHERE `id` = 9;
UPDATE `me_user_rule` SET `pid` = 0, `type` = 'route', `title` = '账户设置', `name` = 'apps-user-list-index-set', `path` = 'apps-user-list', `icon` = 'user-hexagon', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 13, `status` = '1', `update_time` = 1715653365, `create_time` = 1714406166 WHERE `id` = 10;
UPDATE `me_user_rule` SET `pid` = 0, `type` = 'route', `title` = '在线充值', `name` = 'apps-system-online-recharge', `path` = 'apps-system-online-recharge', `icon` = 'recharging', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 12, `status` = '1', `update_time` = 1715653374, `create_time` = 1714406193 WHERE `id` = 11;
UPDATE `me_user_rule` SET `pid` = 0, `type` = 'route', `title` = '套餐购买', `name` = 'pages-pricing', `path` = 'pages-pricing', `icon` = 'shopping-cart-bolt', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 11, `status` = '1', `update_time` = 1715653382, `create_time` = 1714406219 WHERE `id` = 12;
UPDATE `me_user_rule` SET `pid` = 0, `type` = 'route', `title` = '通道管理', `name` = 'tabler-settings-bolt', `path` = '', `icon` = 'settings-bolt', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 10, `status` = '1', `update_time` = 1715653400, `create_time` = 1714406265 WHERE `id` = 13;
UPDATE `me_user_rule` SET `pid` = 13, `type` = 'route', `title` = '通道列表', `name` = 'apps-system-channel-channel-list', `path` = 'apps-system-channel-channel-list', `icon` = 'point-filled', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 16, `status` = '1', `update_time` = 1715653418, `create_time` = 1714406292 WHERE `id` = 14;
UPDATE `me_user_rule` SET `pid` = 13, `type` = 'route', `title` = '通道配置', `name` = 'apps-system-channel-channel-list', `path` = 'apps-system-channel-channel-set', `icon` = 'point-filled', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 15, `status` = '1', `update_time` = 1715653411, `create_time` = 1714406336 WHERE `id` = 15;
UPDATE `me_user_rule` SET `pid` = 0, `type` = 'route', `title` = '订单记录', `name` = 'apps-system-older-list', `path` = 'apps-system-older-list', `icon` = 'cash-banknote', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 9, `status` = '1', `update_time` = 1715653427, `create_time` = 1714406357 WHERE `id` = 16;
");
        $config = \app\admin\model\Config::where('name','version')->find();
        if (!empty($config)){
            $config->value = 'V1.1.1';
            $config->save();
        }
    }
}
