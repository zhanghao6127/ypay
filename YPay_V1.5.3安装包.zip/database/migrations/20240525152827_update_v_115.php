<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV115 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.1.4';
            $config->save();
        }

        $this->execute("ALTER TABLE `me_user_package` 
ADD COLUMN `background` varchar(20) NOT NULL DEFAULT '' COMMENT '背景颜色' AFTER `time`");
        $this->execute("ALTER TABLE `me_user_package` 
ADD COLUMN `button_background` varchar(20) NOT NULL DEFAULT '' COMMENT '按钮颜色' AFTER `background`");
        $this->execute("ALTER TABLE `me_user_package` 
ADD COLUMN `botton_font_color` varchar(20) NOT NULL DEFAULT '' COMMENT '按钮字体颜色' AFTER `button_background`");
        $this->execute("ALTER TABLE `me_user_package` 
ADD COLUMN `gradient_background` varchar(20) NOT NULL DEFAULT '' COMMENT '渐变背景颜色' AFTER `time`");

        $this->execute("UPDATE `me_user_rule` SET `title` = '仪表盘', `name` = 'dashboards-analytics', `path` = 'dashboards-analytics', `icon` = 'dashboard', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 16, `status` = '1', `update_time` = 1716911674, `create_time` = 1714222152 WHERE `name` = 'dashboards-analytics';
UPDATE `me_user_rule` SET `title` = '账户设置', `name` = 'apps-user-list-index-set', `path` = 'apps-user-list', `icon` = 'user-hexagon', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 15, `status` = '1', `update_time` = 1716911681, `create_time` = 1714406166 WHERE `name` = 'apps-user-list-index-set';
UPDATE `me_user_rule` SET `title` = '在线充值', `name` = 'apps-system-online-recharge', `path` = 'apps-system-online-recharge', `icon` = 'recharging', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 14, `status` = '1', `update_time` = 1716911689, `create_time` = 1714406193 WHERE `name` = 'apps-system-online-recharge';
UPDATE `me_user_rule` SET `title` = '套餐购买', `name` = 'pages-pricing', `path` = 'pages-pricing', `icon` = 'shopping-cart-bolt', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 13, `status` = '1', `update_time` = 1716911697, `create_time` = 1714406219 WHERE `name` = 'pages-pricing';
UPDATE `me_user_rule` SET `title` = '通道管理', `name` = 'tabler-settings-bolt', `path` = '', `icon` = 'settings-bolt', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 12, `status` = '1', `update_time` = 1716911704, `create_time` = 1714406265 WHERE `name` = 'tabler-settings-bolt';
UPDATE `me_user_rule` SET  `title` = '通道列表', `name` = 'apps-system-channel-channel-list', `path` = 'apps-system-channel-channel-list', `icon` = 'point-filled', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 16, `status` = '1', `update_time` = 1715653418, `create_time` = 1714406292 WHERE `name` = 'apps-system-channel-channel-list';
UPDATE `me_user_rule` SET  `title` = '通道配置', `name` = 'apps-system-channel-channel-set', `path` = 'apps-system-channel-channel-set', `icon` = 'point-filled', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 15, `status` = '1', `update_time` = 1715653411, `create_time` = 1714406336 WHERE `name` = 'apps-system-channel-channel-set';
UPDATE `me_user_rule` SET `title` = '订单记录', `name` = 'apps-system-older-list', `path` = 'apps-system-older-list', `icon` = 'cash-banknote', `menu_type` = 'tab', `url` = '', `component` = '', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 11, `status` = '1', `update_time` = 1716911711, `create_time` = 1714406357 WHERE `name` = 'apps-system-older-list';
UPDATE `me_user_rule` SET `title` = 'API密钥', `name` = 'apps-user-list-index-api', `path` = 'apps-user-list-index-api', `icon` = 'api-app', `menu_type` = 'tab', `url` = '', `component` = 'apps-user-list-index-api', `no_login_valid` = 0, `extend` = 'none', `remark` = '', `weigh` = 9, `status` = '1', `update_time` = 1716911739, `create_time` = 1716735320 WHERE `name` = 'apps-user-list-index-api';
");
        $this->execute("UPDATE `me_admin_rule` SET  `title` = '会员菜单管理', `name` = 'user/rule', `path` = 'user/rule', `icon` = 'fa fa-th-list', `menu_type` = 'tab', `url` = '', `component` = '/src/views/backend/user/rule/index.vue', `keepalive` = 1, `extend` = 'none', `remark` = '', `weigh` = 92, `status` = '1', `update_time` = 1712046440, `create_time` = 1712046440 WHERE `name` = 'user/rule';
");
        $this->execute("INSERT INTO `me_user_rule`(`pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `no_login_valid`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (0, 'route', 'API密钥', 'apps-user-list-index-api', 'apps-user-list-index-api', 'api-app', 'tab', '', 'apps-user-list-index-api', 0, 'none', '', 9, '1', 1716911739, 1716735320);");
        $this->execute("CREATE TABLE `me_account_offline`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `account_id` int(11) NOT NULL COMMENT '通道ID',
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '掉线原因',
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '临时数据',
  `create_time` bigint(20) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '通道掉线通' ROW_FORMAT = Dynamic;
");
        $config = new \app\admin\model\Config();
        $tmp = $config->where('name','register_method')->find();
        if (empty($tmp)){
            $config->save([
                'name'        => 'register_method',
                'group'       => 'login_config',
                'title'       => '注册验证方法',
                'tip'         => '',
                'type'        => 'selects',
                'value'       => ["username","email"],
                'content'     => "username=用户名\r\nemail=邮箱\r\nmobile=手机号",
                'rule'        => 'required',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ]);
        }

        $config->save([
            'name'        => 'index_jump_method',
            'group'       => 'basics',
            'title'       => '首页跳转Home',
            'tip'         => '',
            'type'        => 'radio',
            'value'       => "1",
            'content'     => "0=关闭\r\n1=开启",
            'rule'        => '',
            'allow_del'   => 0,
            'weigh'       => 0,
            'extend'      => '',
            'inputExtend' => '',
        ]);
    }
}
