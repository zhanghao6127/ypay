<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV153 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.5.3';
            $config->save();
        }
        $this->execute("ALTER TABLE `me_user_basic` 
ADD COLUMN `voice` int(1) NOT NULL DEFAULT 0 COMMENT '语音通知开关 0关闭 1开启' AFTER `new_order`,
ADD COLUMN `voice_content` text NULL COMMENT '语音通知内容' AFTER `voice`");
        $wxTemplate = new \app\admin\model\wxpusher\Template();
        $wxTemplate->where('name', 'login_notice')->update(['content' => '您好,您的账号ID：{uid} ,账户:{nickname}已登录成功,登录IP:{ip},登录时间:{time}']);
        $wxTemplate->where('name', 'offlineline_account_notice')->update(['content' => '您好！，您有{type}通道已掉线，通道ID为：{id}，掉线时间为:{id}，原因：{reason}']);
        $wxTemplate->where('name', 'order_notice')->update(['content' => '你有一个新订单!请留意网站,订单号:{order_no},商品名称:{goods_name},商品金额:{price},收款方式:{type},收款通道ID:{channel_id},下单时间:{create_time},支付时间,{pay_time}']);
        $wxTemplate->where('name', 'balance_notice')->update(['content' => '你的账户还剩{balance},请尽快充值,避免影响使用!']);
        $wxTemplate->where('name', 'new_order')->update(['content' => '你有一个新订单!请留意网站,订单号:{order_no},商品名称:{goods_name},商品金额:{price},付款方式:{type},付款通道ID:{channel_id},下单时间:{create_time}']);

        $data = [
            [
                'name' => 'vip_time_notice',
                'content' => '用户套餐即将到期，请及时购买。',
                'status' => 1,
                'remark' => '用户套餐即将到期',
            ],
            [
                'name' => 'vip_end',
                'content' => '用户会员到期，请及时购买',
                'status' => 1,
                'remark' => '用户会员到期',
                'update_time' => time(),
            ],
        ];
        $wxTemplate->saveAll($data);

        $smsTemplate = new \app\admin\model\sms\Template();
        $data = null;
        $data = [
            [
                'title' => '登录通知',
                'code' => 'login_notice',
                'content' => '您好,您的账号ID：{uid} ,账户:{nickname}已登录成功,登录IP:{ip},登录时间:{time}',
            ],
            [
                'title' => '通道下线',
                'code' => 'offlineline_account_notice',
                'content' => '您好！，您有{type}通道已掉线，通道ID为：{id}，掉线时间为:{id}，原因：{reason}',
            ],
            [
                'title' => '新订单',
                'code' => 'new_order',
                'content' => '你有一个新订单!请留意网站,订单号:{order_no},商品名称:{goods_name},商品金额:{price},付款方式:{type},付款通道ID:{channel_id},下单时间:{create_time}',
            ],
            [
                'title' => '订单收款',
                'code' => 'order_notice',
                'content' => '你有一个新订单!请留意网站,订单号:{order_no},商品名称:{goods_name},商品金额:{price},收款方式:{type},收款通道ID:{channel_id},下单时间:{create_time},支付时间,{pay_time}'
            ],
            [
                'title' => '余额不足',
                'code' => 'balance_notice',
                'content' => '你的账户还剩{balance},请尽快充值,避免影响使用!',
            ],
            [
                'title' => '新订单',
                'code' => 'new_order',
                'content' => '你有一个新订单!请留意网站,订单号:{order_no},商品名称:{goods_name},商品金额:{price},付款方式:{type},付款通道ID:{channel_id},下单时间:{create_time}',
            ],
            [
                'title' => '用户会员到期',
                'code' => 'vip_end',
                'content' => '用户会员到期，请及时购买',
            ],
            [
                'title' => '用户套餐即将到期',
                'code' => 'vip_time_notice',
                'content' => '用户套餐即将到期，请及时购买。',
            ],
        ];
        $smsTemplate->saveAll($data);

        $mailTemplate = new \app\admin\model\mail\Template();
        $mailTemplate->where('name', 'forgot')->update([
            'content' => '正在找回密码，验证码{code}',
        ]);
        $mailTemplate->where('name', 'login')->update([
            'content' => 'Ypay登录验证码：{code}',
        ]);
        $mailTemplate->where('name', 'register')->update([
            'content' => 'Ypay注册验证码：{code}',
        ]);
        $mailTemplate->where('name', 'bind')->update([
            'content' => 'Ypay邮箱绑定验证码：{code}',
        ]);
        $mailTemplate->where('name', 'unbind')->update([
            'content' => 'Ypay邮箱解绑验证码：{code}',
        ]);
        $mailTemplate->where('name', 'login_notice')->update([
            'content' => '您好,您的账号ID：{uid} ,账户:{nickname}已登录成功,登录IP:{ip},登录时间:{time}',
        ]);
        $mailTemplate->where('name', 'offlineline_account_notice')->update([
            'content' => '您好！，您有{type}通道已掉线，通道ID为：{id}，掉线时间为:{id}，原因：{reason}',
        ]);
        $mailTemplate->where('name', 'order_notice')->update([
            'content' => '你有一个新订单!请留意网站,订单号:{order_no},商品名称:{goods_name},商品金额:{price},收款方式:{type},收款通道ID:{channel_id},下单时间:{create_time},支付时间,{pay_time}',
        ]);
        $mailTemplate->where('name', 'balance_notice')->update([
            'content' => '你的账户还剩{balance},请尽快充值,避免影响使用!',
        ]);
        $mailTemplate->where('name', 'vip_time_notice')->update([
            'content' => '用户套餐即将到期，请及时购买。',
        ]);
        $mailTemplate->where('name', 'vip_end')->update([
            'content' => '用户会员到期，请及时购买',
        ]);
        $mailTemplate->where('name', 'new_order')->update([
            'content' => '你有一个新订单!请留意网站,订单号:{order_no},商品名称:{goods_name},商品金额:{price},付款方式:{type},付款通道ID:{channel_id},下单时间:{create_time}',
        ]);

    }
}
