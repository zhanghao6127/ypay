<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV103 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $data = [
            'name'      => 'username_check',
            'group'     => 'login_config',
            'title'     => '前台注册用户名验证',
            'type'      => 'selects',
            'value'     =>  ["2","3"],
            'content'   => "1=无限制\r\n2=数字\r\n3=字母",
            'rule'      => 'required',
            'allow_del' => 1,
            'weigh'     => 0,
            'extend'     => '',
            'inputExtend'     => '',
        ];
        $config = new \app\admin\model\Config();
        $config->save($data);

        $config = new \app\admin\model\Config();
        $config = $config->where('name','version')->find();
        if (!empty($config)){
            $config->value = 'V1.0.3';
            $config->save();
        }
        $this->execute("ALTER TABLE `me_order` 
MODIFY COLUMN `h5_qrurl` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT 'h5二维码url' AFTER `qrcode`;");
        $this->execute("ALTER TABLE `me_order` 
ADD COLUMN `name` varchar(255) NOT NULL DEFAULT '' COMMENT '商品名称' AFTER `uid`;");
    }
}
