<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV118 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $configModel = new \app\admin\model\Config();
        $group_config = $configModel->where('name', 'config_group')->find();
        $tmp          = $group_config->value;
        $new_tmp = [];
        foreach ($tmp as $v){
            if ($v['key'] != 'config_quick_entrance'){
                $new_tmp[] = $v;
            }
        }
        $new_tmp[] = ['key' => "proclamation_config", 'value' => "公告配置"];
        $group_config->value = $new_tmp;
        $group_config->save();

        $quick = $configModel->where('name','config_quick_entrance')->find();
        if (!empty($quick->value[1])){
            $quick->value = [[$quick->value[1]]];
            $quick->save();
        }

        $data = [
            [
                'name'        => 'account_proclamation',
                'group'       => 'proclamation_config',
                'title'       => '通道页面公告',
                'tip'         => '',
                'type'        => 'editor',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'registet_proclamation',
                'group'       => 'proclamation_config',
                'title'       => '注册页面弹窗公告',
                'tip'         => '',
                'type'        => 'editor',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'index_proclamation',
                'group'       => 'proclamation_config',
                'title'       => '首页弹窗',
                'tip'         => '',
                'type'        => 'editor',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],

            [
                'name'        => 'min_price',
                'group'       => 'api_config',
                'title'       => '支付最小金额',
                'tip'         => '',
                'type'        => 'number',
                'value'       => 0,
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'max_price',
                'group'       => 'api_config',
                'title'       => '支付最大金额',
                'tip'         => '',
                'type'        => 'number',
                'value'       => 0,
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'block_keywords',
                'group'       => 'api_config',
                'title'       => '屏蔽关键字',
                'tip'         => '',
                'type'        => 'textarea',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'block_keywords_msg',
                'group'       => 'api_config',
                'title'       => '提示信息',
                'tip'         => '',
                'type'        => 'string',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'register_gift_packge',
                'group'       => 'login_config',
                'title'       => '注册赠送会员套餐',
                'tip'         => '',
                'type'        => 'remoteSelect',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'wxpay_clerk_key',
                'group'       => 'api_config',
                'title'       => '店员通道密钥',
                'tip'         => '',
                'type'        => 'string',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'wxpay_clerk_img',
                'group'       => 'api_config',
                'title'       => '店员通道图片',
                'tip'         => '',
                'type'        => 'image',
                'value'       => '',
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
        ];
        $configModel->saveAll($data);

        $qrcode = $configModel->where('name', 'analysis_qrcode_method')->find();
        if (!empty($qrcode)) {
            $qrcode->content = json_encode([1 => '本地', 2 => 'API']);
            $qrcode->save();
        }

        $this->execute("ALTER TABLE `me_user_login_log` 
MODIFY COLUMN `ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'IP' AFTER `info`");
        $this->execute("ALTER TABLE `me_cloud` 
MODIFY COLUMN `cloud_type` enum('1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '云端类型:1=V1,2=V2,3=V3,4=PC' AFTER `status`");

        $this->execute("ALTER TABLE `me_user_basic` 
ADD COLUMN `order_notice` int(1) NOT NULL DEFAULT 0 COMMENT '订单收款通知' AFTER `diy_order_prefix`,
ADD COLUMN `offlineline_account_notice` int(1) NOT NULL DEFAULT 0 COMMENT '通道掉线通知' AFTER `order_notice`,
ADD COLUMN `login_notice` int(1) NOT NULL DEFAULT 0 COMMENT '账号登录通知' AFTER `offlineline_account_notice`,
ADD COLUMN `balance_notice` int(1) NOT NULL DEFAULT 0 COMMENT '余额不足通知' AFTER `login_notice`");

        $this->execute("ALTER TABLE `me_user_basic` 
ADD COLUMN `notice_method` int(1) NOT NULL DEFAULT 1 COMMENT '通知方式：1：邮箱 2：手机' AFTER `balance_notice`
");
        if (!empty($config)) {
            $config->value = 'V1.2.0';
            $config->save();
        }

    }
}
