<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV130 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.3.0';
            $config->save();
        }
        $configModel = new \app\admin\model\Config();
        $data =[
            'name'        => 'vip_time_check',
            'group'       => 'api_config',
            'title'       => '用户套餐到期提醒天数',
            'tip'         => '套餐到期前通知，天数 0 = 不开启',
            'type'        => 'number',
            'value'       => '3',
            'content'     => "",
            'rule'        => '',
            'allow_del'   => 0,
            'weigh'       => 0,
            'extend'      => '',
            'inputExtend' => '',
        ];
        $configModel->save($data);

        $this->execute("ALTER TABLE `me_user_basic` 
ADD COLUMN `balance_notice_price` int(10) NOT NULL DEFAULT 0 COMMENT '余额不足提醒限额' AFTER `notice_method`");
        $this->execute("INSERT INTO `me_channel_type`(`name`, `type`, `code`) VALUES ('微信店员', 'wxpay', 'wxpay_clerk')");

        $this->execute("INSERT INTO `me_mail_template`(`name`, `title`, `content`, `status`, `remark`, `update_time`, `create_time`) VALUES ('login_notice', '用户登录系统', '用户{nickname}于{time}登录系统，登录IP：{ip}', 1, '用户登录通知邮件', 1718222646, 1718222646);
INSERT INTO `me_mail_template`(`name`, `title`, `content`, `status`, `remark`, `update_time`, `create_time`) VALUES ('offlineline_account_notice', '用户通道下线', '用户{type}通道下线，通道ID：{id},下线时间：{time}', 1, '', 1718222713, 1718222713);
INSERT INTO `me_mail_template`(`name`, `title`, `content`, `status`, `remark`, `update_time`, `create_time`) VALUES ('order_notice', '订单收款通知', '订单：{order}于{time}收款：{price}元', 1, '', 1718222782, 1718222782);
INSERT INTO `me_mail_template`(`name`, `title`, `content`, `status`, `remark`, `update_time`, `create_time`) VALUES ('balance_notice', '用户余额不足', '用户余额不足，请及时充值', 1, '', 1718223097, 1718223097);
INSERT INTO `me_mail_template`(`name`, `title`, `content`, `status`, `remark`, `update_time`, `create_time`) VALUES ('vip_time_notice', '用户套餐即将到期', '用户套餐即将到期，请及时购买。', 1, '', 1718223313, 1718223313);
");
    }
}
