<?php

use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV117 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.1.7';
            $config->save();
        }

        $data = [
            [
                'name'        => 'registerd_gifts',
                'group'       => 'login_config',
                'title'       => '注册赠送余额',
                'tip'         => '',
                'type'        => 'number',
                'value'       => 0,
                'content'     => "",
                'rule'        => '',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'create_qrcode_method',
                'group'       => 'api_config',
                'title'       => '生码接口切换',
                'tip'         => '',
                'type'        => 'radio',
                'value'       => 1,
                'content'     => "1=本地\r\n2=官方",
                'rule'        => 'required',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'analysis_qrcode_method',
                'group'       => 'api_config',
                'title'       => '二维码解析切换',
                'tip'         => '',
                'type'        => 'radio',
                'value'       => 1,
                'content'     => "1=本地\r\n2=官方",
                'rule'        => 'required',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
            [
                'name'        => 'timeout_number',
                'group'       => 'api_config',
                'title'       => '用户订单最大超时时间',
                'tip'         => '',
                'type'        => 'number',
                'value'       => 300,
                'content'     => "",
                'rule'        => 'required',
                'allow_del'   => 0,
                'weigh'       => 0,
                'extend'      => '',
                'inputExtend' => '',
            ],
        ];
        $configModel = new \app\admin\model\Config();
        $configModel->saveAll($data);

        $group_config = \app\admin\model\Config::where('name', 'config_group')->find();
        $tmp          = $group_config->value;
        $tmp[]               = ['key' => "api_config", 'value' => "接口配置"];
        $group_config->value = ($tmp);
        $group_config->save();
    }
}
