<?php

use app\admin\model\AdminRule;
use app\common\library\Menu;
use think\migration\Migrator;
use think\migration\db\Column;

class VupdateV148 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $this->execute("ALTER TABLE `me_order` 
MODIFY COLUMN `notify_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '异步回调地址' AFTER `pay_type`,
MODIFY COLUMN `return_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '同步地址' AFTER `notify_url`");
        $this->execute("CREATE TABLE `me_verify_config`  (
  `key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '字段',
  `val` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '数据值',
  `title` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '名称',
  `update_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`key`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '安全验证配置表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of me_verify_config
-- ----------------------------
INSERT INTO `me_verify_config` VALUES ('calculate', '{\"spec\":[\"+\",\"-\",\"*\",\"\\/\"],\"data\":\"10\",\"expiry\":\"10\"}', '计算验证码配置', 1724382262);
INSERT INTO `me_verify_config` VALUES ('captcha', '{\"length\":\"4\",\"useNoise\":\"1\",\"useCurve\":\"0\",\"bg\":\"rgba(255, 255, 255, 1)\",\"codeSet\":\"2345678abcdefhijkmnpqrstuvwxyzABCDEFGHJKLMNPQRTUVWXY\",\"expiry\":\"10\",\"size\":\"22\"}', '验证码配置', 1724382262);
INSERT INTO `me_verify_config` VALUES ('mail', '{\"length\":\"4\",\"codeSet\":\"2345678abcdefhijkmnpqrstuvwxyzABCDEFGHJKLMNPQRTUVWXY\",\"expiry\":\"10\"}', '邮箱验证码配置', 1724382262);
INSERT INTO `me_verify_config` VALUES ('text', '{\"length\":\"4\",\"codeSet\":\"\\u4eec\\u4ee5\\u6211\\u5230\\u4ed6\\u4f1a\\u4f5c\\u65f6\\u8981\\u52a8\\u56fd\\u4ea7\\u7684\\u4e00\\u662f\\u5de5\\u5c31\\u5e74\\u9636\\u4e49\\u53d1\\u6210\\u90e8\\u6c11\\u53ef\\u51fa\\u80fd\\u65b9\\u8fdb\\u5728\\u4e86\\u4e0d\\u548c\\u6709\\u5927\\u8fd9\\u4e3b\\u4e2d\\u4eba\\u4e0a\\u4e3a\\u6765\\u5206\\u751f\\u5bf9\\u4e8e\\u5b66\\u4e0b\\u7ea7\\u5730\\u4e2a\\u7528\\u540c\\u884c\\u9762\\u8bf4\\u79cd\\u8fc7\\u547d\\u5ea6\\u9769\\u800c\\u591a\\u5b50\\u540e\\u81ea\\u793e\\u52a0\\u5c0f\\u673a\\u4e5f\\u7ecf\\u529b\\u7ebf\\u672c\\u7535\\u9ad8\\u91cf\\u957f\\u515a\\u5f97\\u5b9e\\u5bb6\\u5b9a\\u6df1\\u6cd5\\u8868\\u7740\\u6c34\\u7406\\u5316\\u4e89\\u73b0\\u6240\\u4e8c\\u8d77\\u653f\\u4e09\\u597d\\u5341\\u6218\\u65e0\\u519c\\u4f7f\\u6027\\u524d\\u7b49\\u53cd\\u4f53\\u5408\\u6597\\u8def\\u56fe\\u628a\\u7ed3\\u7b2c\\u91cc\\u6b63\\u65b0\\u5f00\\u8bba\\u4e4b\\u7269\\u4ece\\u5f53\\u4e24\\u4e9b\\u8fd8\\u5929\\u8d44\\u4e8b\\u961f\\u6279\\u70b9\\u80b2\\u91cd\\u5176\\u601d\\u4e0e\\u95f4\\u5185\\u53bb\\u56e0\\u4ef6\\u65e5\\u5229\\u76f8\\u7531\\u538b\\u5458\\u6c14\\u4e1a\\u4ee3\\u5168\\u7ec4\\u6570\\u679c\\u671f\\u5bfc\\u5e73\\u5404\\u57fa\\u6216\\u6708\\u6bdb\\u7136\\u5982\\u5e94\\u5f62\\u60f3\\u5236\\u5fc3\\u6837\\u5e72\\u90fd\\u5411\\u53d8\\u5173\\u95ee\\u6bd4\\u5c55\\u90a3\\u5b83\\u6700\\u53ca\\u5916\\u6ca1\\u770b\\u6cbb\\u63d0\\u4e94\\u89e3\\u7cfb\\u6797\\u8005\\u7c73\\u7fa4\\u5934\\u610f\\u53ea\\u660e\\u56db\\u9053\\u9a6c\\u8ba4\\u6b21\\u6587\\u901a\\u4f46\\u6761\\u8f83\\u514b\\u53c8\\u516c\\u5b54\\u9886\\u519b\\u6d41\\u5165\\u63a5\\u5e2d\\u4f4d\\u60c5\\u8fd0\\u5668\\u5e76\\u98de\\u539f\\u6cb9\\u653e\\u7acb\\u9898\\u8d28\\u6307\\u5efa\\u533a\\u9a8c\\u6d3b\\u4f17\\u5f88\\u6559\\u51b3\\u7279\\u6b64\\u5e38\\u77f3\\u5f3a\\u6781\\u571f\\u5c11\\u5df2\\u6839\\u5171\\u76f4\\u56e2\\u7edf\\u5f0f\\u8f6c\\u522b\\u9020\\u5207\\u4e5d\\u4f60\\u53d6\\u897f\\u6301\\u603b\\u6599\\u8fde\\u4efb\\u5fd7\\u89c2\\u8c03\\u4e03\\u4e48\\u5c71\\u7a0b\\u767e\\u62a5\\u66f4\\u89c1\\u5fc5\\u771f\\u4fdd\\u70ed\\u59d4\\u624b\\u6539\\u7ba1\\u5904\\u5df1\\u5c06\\u4fee\\u652f\\u8bc6\\u75c5\\u8c61\\u51e0\\u5148\\u8001\\u5149\\u4e13\\u4ec0\\u516d\\u578b\\u5177\\u793a\\u590d\\u5b89\\u5e26\\u6bcf\\u4e1c\\u589e\\u5219\\u5b8c\\u98ce\\u56de\\u5357\\u5e7f\\u52b3\\u8f6e\\u79d1\\u5317\\u6253\\u79ef\\u8f66\\u8ba1\\u7ed9\\u8282\\u505a\\u52a1\\u88ab\\u6574\\u8054\\u6b65\\u7c7b\\u96c6\\u53f7\\u5217\\u6e29\\u88c5\\u5373\\u6beb\\u77e5\\u8f74\\u7814\\u5355\\u8272\\u575a\\u636e\\u901f\\u9632\\u53f2\\u62c9\\u4e16\\u8bbe\\u8fbe\\u5c14\\u573a\\u7ec7\\u5386\\u82b1\\u53d7\\u6c42\\u4f20\\u53e3\\u65ad\\u51b5\\u91c7\\u7cbe\\u91d1\\u754c\\u54c1\\u5224\\u53c2\\u5c42\\u6b62\\u8fb9\\u6e05\\u81f3\\u4e07\\u786e\\u7a76\\u4e66\\u672f\\u72b6\\u5382\\u987b\\u79bb\\u518d\\u76ee\\u6d77\\u4ea4\\u6743\\u4e14\\u513f\\u9752\\u624d\\u8bc1\\u4f4e\\u8d8a\\u9645\\u516b\\u8bd5\\u89c4\\u65af\\u8fd1\\u6ce8\\u529e\\u5e03\\u95e8\\u94c1\\u9700\\u8d70\\u8bae\\u53bf\\u5175\\u56fa\\u9664\\u822c\\u5f15\\u9f7f\\u5343\\u80dc\\u7ec6\\u5f71\\u6d4e\\u767d\\u683c\\u6548\\u7f6e\\u63a8\\u7a7a\\u914d\\u5200\\u53f6\\u7387\\u8ff0\\u4eca\\u9009\\u517b\\u5fb7\\u8bdd\\u67e5\\u5dee\\u534a\\u654c\\u59cb\\u7247\\u65bd\\u54cd\\u6536\\u534e\\u89c9\\u5907\\u540d\\u7ea2\\u7eed\\u5747\\u836f\\u6807\\u8bb0\\u96be\\u5b58\\u6d4b\\u58eb\\u8eab\\u7d27\\u6db2\\u6d3e\\u51c6\\u65a4\\u89d2\\u964d\\u7ef4\\u677f\\u8bb8\\u7834\\u8ff0\\u6280\\u6d88\\u5e95\\u5e8a\\u7530\\u52bf\\u7aef\\u611f\\u5f80\\u795e\\u4fbf\\u8d3a\\u6751\\u6784\\u7167\\u5bb9\\u975e\\u641e\\u4e9a\\u78e8\\u65cf\\u706b\\u6bb5\\u7b97\\u9002\\u8bb2\\u6309\\u503c\\u7f8e\\u6001\\u9ec4\\u6613\\u5f6a\\u670d\\u65e9\\u73ed\\u9ea6\\u524a\\u4fe1\\u6392\\u53f0\\u58f0\\u8be5\\u51fb\\u7d20\\u5f20\\u5bc6\\u5bb3\\u4faf\\u8349\\u4f55\\u6811\\u80a5\\u7ee7\\u53f3\\u5c5e\\u5e02\\u4e25\\u5f84\\u87ba\\u68c0\\u5de6\\u9875\\u6297\\u82cf\\u663e\\u82e6\\u82f1\\u5feb\\u79f0\\u574f\\u79fb\\u7ea6\\u5df4\\u6750\\u7701\\u9ed1\\u6b66\\u57f9\\u8457\\u6cb3\\u5e1d\\u4ec5\\u9488\\u600e\\u690d\\u4eac\\u52a9\\u5347\\u738b\\u773c\\u5979\\u6293\\u542b\\u82d7\\u526f\\u6742\\u666e\\u8c08\\u56f4\\u98df\\u5c04\\u6e90\\u4f8b\\u81f4\\u9178\\u65e7\\u5374\\u5145\\u8db3\\u77ed\\u5212\\u5242\\u5ba3\\u73af\\u843d\\u9996\\u5c3a\\u6ce2\\u627f\\u7c89\\u8df5\\u5e9c\\u9c7c\\u968f\\u8003\\u523b\\u9760\\u591f\\u6ee1\\u592b\\u5931\\u5305\\u4f4f\\u4fc3\\u679d\\u5c40\\u83cc\\u6746\\u5468\\u62a4\\u5ca9\\u5e08\\u4e3e\\u66f2\\u6625\\u5143\\u8d85\\u8d1f\\u7802\\u5c01\\u6362\\u592a\\u6a21\\u8d2b\\u51cf\\u9633\\u626c\\u6c5f\\u6790\\u4ea9\\u6728\\u8a00\\u7403\\u671d\\u533b\\u6821\\u53e4\\u5462\\u7a3b\\u5b8b\\u542c\\u552f\\u8f93\\u6ed1\\u7ad9\\u53e6\\u536b\\u5b57\\u9f13\\u521a\\u5199\\u5218\\u5fae\\u7565\\u8303\\u4f9b\\u963f\\u5757\\u67d0\\u529f\\u5957\\u53cb\\u9650\\u9879\\u4f59\\u5012\\u5377\\u521b\\u5f8b\\u96e8\\u8ba9\\u9aa8\\u8fdc\\u5e2e\\u521d\\u76ae\\u64ad\\u4f18\\u5360\\u6b7b\\u6bd2\\u5708\\u4f1f\\u5b63\\u8bad\\u63a7\\u6fc0\\u627e\\u53eb\\u4e91\\u4e92\\u8ddf\\u88c2\\u7cae\\u7c92\\u6bcd\\u7ec3\\u585e\\u94a2\\u9876\\u7b56\\u53cc\\u7559\\u8bef\\u7840\\u5438\\u963b\\u6545\\u5bf8\\u76fe\\u665a\\u4e1d\\u5973\\u6563\\u710a\\u529f\\u682a\\u4eb2\\u9662\\u51b7\\u5f7b\\u5f39\\u9519\\u6563\\u5546\\u89c6\\u827a\\u706d\\u7248\\u70c8\\u96f6\\u5ba4\\u8f7b\\u8840\\u500d\\u7f3a\\u5398\\u6cf5\\u5bdf\\u7edd\\u5bcc\\u57ce\\u51b2\\u55b7\\u58e4\\u7b80\\u5426\\u67f1\\u674e\\u671b\\u76d8\\u78c1\\u96c4\\u4f3c\\u56f0\\u5de9\\u76ca\\u6d32\\u8131\\u6295\\u9001\\u5974\\u4fa7\\u6da6\\u76d6\\u6325\\u8ddd\\u89e6\\u661f\\u677e\\u9001\\u83b7\\u5174\\u72ec\\u5b98\\u6df7\\u7eaa\\u4f9d\\u672a\\u7a81\\u67b6\\u5bbd\\u51ac\\u7ae0\\u6e7f\\u504f\\u7eb9\\u5403\\u6267\\u9600\\u77ff\\u5be8\\u8d23\\u719f\\u7a33\\u593a\\u786c\\u4ef7\\u52aa\\u7ffb\\u5947\\u7532\\u9884\\u804c\\u8bc4\\u8bfb\\u80cc\\u534f\\u635f\\u68c9\\u4fb5\\u7070\\u867d\\u77db\\u539a\\u7f57\\u6ce5\\u8f9f\\u544a\\u5375\\u7bb1\\u638c\\u6c27\\u6069\\u7231\\u505c\\u66fe\\u6eb6\\u8425\\u7ec8\\u7eb2\\u5b5f\\u94b1\\u5f85\\u5c3d\\u4fc4\\u7f29\\u6c99\\u9000\\u9648\\u8ba8\\u594b\\u68b0\\u8f7d\\u80de\\u5e7c\\u54ea\\u5265\\u8feb\\u65cb\\u5f81\\u69fd\\u5012\\u63e1\\u62c5\\u4ecd\\u5440\\u9c9c\\u5427\\u5361\\u7c97\\u4ecb\\u94bb\\u9010\\u5f31\\u811a\\u6015\\u76d0\\u672b\\u9634\\u4e30\\u96fe\\u51a0\\u4e19\\u8857\\u83b1\\u8d1d\\u8f90\\u80a0\\u4ed8\\u5409\\u6e17\\u745e\\u60ca\\u987f\\u6324\\u79d2\\u60ac\\u59c6\\u70c2\\u68ee\\u7cd6\\u5723\\u51f9\\u9676\\u8bcd\\u8fdf\\u8695\\u4ebf\\u77e9\\u5eb7\\u9075\\u7267\\u906d\\u5e45\\u56ed\\u8154\\u8ba2\\u9999\\u8089\\u5f1f\\u5c4b\\u654f\\u6062\\u5fd8\\u7f16\\u5370\\u8702\\u6025\\u62ff\\u6269\\u4f24\\u98de\\u9732\\u6838\\u7f18\\u6e38\\u632f\\u64cd\\u592e\\u4f0d\\u57df\\u751a\\u8fc5\\u8f89\\u5f02\\u5e8f\\u514d\\u7eb8\\u591c\\u4e61\\u4e45\\u96b6\\u7f38\\u5939\\u5ff5\\u5170\\u6620\\u6c9f\\u4e59\\u5417\\u5112\\u6740\\u6c7d\\u78f7\\u8270\\u6676\\u63d2\\u57c3\\u71c3\\u6b22\\u94c1\\u8865\\u54b1\\u82bd\\u6c38\\u74e6\\u503e\\u9635\\u78b3\\u6f14\\u5a01\\u9644\\u7259\\u82bd\\u6c38\\u74e6\\u659c\\u704c\\u6b27\\u732e\\u987a\\u732a\\u6d0b\\u8150\\u8bf7\\u900f\\u53f8\\u5371\\u62ec\\u8109\\u5b9c\\u7b11\\u82e5\\u5c3e\\u675f\\u58ee\\u66b4\\u4f01\\u83dc\\u7a57\\u695a\\u6c49\\u6108\\u7eff\\u62d6\\u725b\\u4efd\\u67d3\\u65e2\\u79cb\\u904d\\u953b\\u7389\\u590f\\u7597\\u5c16\\u6b96\\u4e95\\u8d39\\u5dde\\u8bbf\\u5439\\u8363\\u94dc\\u6cbf\\u66ff\\u6eda\\u5ba2\\u53ec\\u65f1\\u609f\\u523a\\u8111\\u63aa\\u8d2f\\u85cf\\u6562\\u4ee4\\u9699\\u7089\\u58f3\\u786b\\u7164\\u8fce\\u94f8\\u7c98\\u63a2\\u4e34\\u8584\\u65ec\\u5584\\u798f\\u7eb5\\u62e9\\u793c\\u613f\\u4f0f\\u6b8b\\u96f7\\u5ef6\\u70df\\u53e5\\u7eaf\\u6e10\\u8015\\u8dd1\\u6cfd\\u6162\\u683d\\u9c81\\u8d64\\u7e41\\u5883\\u6f6e\\u6a2a\\u6389\\u9525\\u5e0c\\u6c60\\u8d25\\u8239\\u5047\\u4eae\\u8c13\\u6258\\u4f19\\u54f2\\u6000\\u5272\\u6446\\u8d21\\u5448\\u52b2\\u8d22\\u4eea\\u6c89\\u70bc\\u9ebb\\u7f6a\\u7956\\u606f\\u8f66\\u7a7f\\u8d27\\u9500\\u9f50\\u9f20\\u62bd\\u753b\\u9972\\u9f99\\u5e93\\u5b88\\u7b51\\u623f\\u6b4c\\u5bd2\\u559c\\u54e5\\u6d17\\u8680\\u5e9f\\u7eb3\\u8179\\u4e4e\\u5f55\\u955c\\u5987\\u6076\\u8102\\u5e84\\u64e6\\u9669\\u8d5e\\u949f\\u6447\\u5178\\u67c4\\u8fa9\\u7af9\\u8c37\\u5356\\u4e71\\u865a\\u6865\\u5965\\u4f2f\\u8d76\\u5782\\u9014\\u989d\\u58c1\\u7f51\\u622a\\u91ce\\u9057\\u9759\\u8c0b\\u5f04\\u6302\\u8bfe\\u9547\\u5984\\u76db\\u8010\\u63f4\\u624e\\u8651\\u952e\\u5f52\\u7b26\\u5e86\\u805a\\u7ed5\\u6469\\u5fd9\\u821e\\u9047\\u7d22\\u987e\\u80f6\\u7f8a\\u6e56\\u9489\\u4ec1\\u97f3\\u8ff9\\u788e\\u4f38\\u706f\\u907f\\u6cdb\\u4ea1\\u7b54\\u52c7\\u9891\\u7687\\u67f3\\u54c8\\u63ed\\u7518\\u8bfa\\u6982\\u5baa\\u6d53\\u5c9b\\u88ad\\u8c01\\u6d2a\\u8c22\\u70ae\\u6d47\\u6591\\u8baf\\u61c2\\u7075\\u86cb\\u95ed\\u5b69\\u91ca\\u4e73\\u5de8\\u5f92\\u79c1\\u94f6\\u4f0a\\u666f\\u5766\\u7d2f\\u5300\\u9709\\u675c\\u4e50\\u52d2\\u9694\\u5f2f\\u7ee9\\u62db\\u7ecd\\u80e1\\u547c\\u75db\\u5cf0\\u96f6\\u67f4\\u7c27\\u5348\\u8df3\\u5c45\\u5c1a\\u4e01\\u79e6\\u7a0d\\u8ffd\\u6881\\u6298\\u8017\\u78b1\\u6b8a\\u5c97\\u6316\\u6c0f\\u5203\\u5267\\u5806\\u8d6b\\u8377\\u80f8\\u8861\\u52e4\\u819c\\u7bc7\\u767b\\u9a7b\\u6848\\u520a\\u79e7\\u7f13\\u51f8\\u5f79\\u526a\\u5ddd\\u96ea\\u94fe\\u6e14\\u5566\\u8138\\u6237\\u6d1b\\u5b62\\u52c3\\u76df\\u4e70\\u6768\\u5b97\\u7126\\u8d5b\\u65d7\\u6ee4\\u7845\\u70ad\\u80a1\\u5750\\u84b8\\u51dd\\u7adf\\u9677\\u67aa\\u9ece\\u6551\\u5192\\u6697\\u6d1e\\u72af\\u7b52\\u60a8\\u5b8b\\u5f27\\u7206\\u8c2c\\u6d82\\u5473\\u6d25\\u81c2\\u969c\\u8910\\u9646\\u554a\\u5065\\u5c0a\\u8c46\\u62d4\\u83ab\\u62b5\\u6851\\u5761\\u7f1d\\u8b66\\u6311\\u6c61\\u51b0\\u67ec\\u5634\\u5565\\u996d\\u5851\\u5bc4\\u8d75\\u558a\\u57ab\\u4e39\\u6e21\\u8033\\u5228\\u864e\\u7b14\\u7a00\\u6606\\u6d6a\\u8428\\u8336\\u6ef4\\u6d45\\u62e5\\u7a74\\u8986\\u4f26\\u5a18\\u5428\\u6d78\\u8896\\u73e0\\u96cc\\u5988\\u7d2b\\u620f\\u5854\\u9524\\u9707\\u5c81\\u8c8c\\u6d01\\u5256\\u7262\\u950b\\u7591\\u9738\\u95ea\\u57d4\\u731b\\u8bc9\\u5237\\u72e0\\u5ffd\\u707e\\u95f9\\u4e54\\u5510\\u6f0f\\u95fb\\u6c88\\u7194\\u6c2f\\u8352\\u830e\\u7537\\u51e1\\u62a2\\u50cf\\u6d46\\u65c1\\u73bb\\u4ea6\\u5fe0\\u5531\\u8499\\u4e88\\u7eb7\\u6355\\u9501\\u5c24\\u4e58\\u4e4c\\u667a\\u6de1\\u5141\\u53db\\u755c\\u4fd8\\u6478\\u9508\\u626b\\u6bd5\\u7483\\u5b9d\\u82af\\u7237\\u9274\\u79d8\\u51c0\\u848b\\u9499\\u80a9\\u817e\\u67af\\u629b\\u8f68\\u5802\\u62cc\\u7238\\u5faa\\u8bf1\\u795d\\u52b1\\u80af\\u9152\\u7ef3\\u7a77\\u5858\\u71e5\\u6ce1\\u888b\\u6717\\u5582\\u94dd\\u8f6f\\u6e20\\u9897\\u60ef\\u8d38\\u7caa\\u7efc\\u5899\\u8d8b\\u5f7c\\u5c4a\\u58a8\\u788d\\u542f\\u9006\\u5378\\u822a\\u8863\\u5b59\\u9f84\\u5cad\\u9a97\\u4f11\\u501f\",\"expiry\":\"10\"}', '文本验证码配置', 1724382262);
");
        $pMenu = AdminRule::where('name', 'verify')->value('id');
        if (!$pMenu) {
            $pid = AdminRule::where('name', 'routine')->value('id');
            $menu = [
                [
                    'type'      => 'menu',
                    'pid'       => $pid,
                    'title'     => '安全验证配置',
                    'name'      => 'verify',
                    'path'      => 'verify',
                    'icon'      => 'fa fa-shield',
                    'menu_type' => 'tab',
                    'component' => '/src/views/backend/verify/config.vue',
                ]
            ];
            Menu::create($menu);
            $pMenu = AdminRule::where('name', 'verify')->value('id');
        }
        $menu = [
            ['type' => 'button', 'title' => '查看', 'name' => 'verify/config/getConfig', 'pid' => $pMenu,],
            ['type' => 'button', 'title' => '修改', 'name' => 'verify/config/saveConfig', 'pid' => $pMenu,],
        ];
        Menu::create($menu);
        $configModel = new \app\admin\model\Config();
        $data = [
            [
                'name'        => 'captcha_open',
                'group'       => 'security_config',
                'title'       => '发送前验证',
                'tip'         => '',
                'type'        => 'radio',
                'value'       => 0,
                'content'     => "0=关闭\r\n1=开启",
                'rule'        => '',
                'extend' => '',
                'allow_del'   => 0,
                'weigh'      => 0,
                'inputExtend' => '',

            ],
            [
                'name'        => 'captcha_method',
                'group'       => 'security_config',
                'title'       => '验证码方式',
                'tip'         => '',
                'type'        => 'select',
                'value'       => 1,
                'content'     => "1=图片验证码\r\n2=文本\r\n3=计算验证码",
                'rule'        => '',
                'allow_del'   => 0,
                'extend' => '',
                'weigh'      => 0,
                'inputExtend' => '',

            ],
        ];
        $configModel->saveAll($data);

        $config = \app\admin\model\Config::where('name', 'version')->find();
        if (!empty($config)) {
            $config->value = 'V1.4.8';
            $config->save();
        }
    }
}
