<?php

use app\common\library\Menu;
use think\migration\Migrator;
use think\migration\db\Column;

class UpdateV105 extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $this->execute("CREATE TABLE IF NOT EXISTS `me_sms_template`
(
    `id`         int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `title`      varchar(100) NOT NULL DEFAULT '' COMMENT '模板标题',
    `code`       varchar(100) NOT NULL DEFAULT '' COMMENT '唯一标识',
    `template`   varchar(100) NOT NULL DEFAULT '' COMMENT '服务商模板ID',
    `content`    text COMMENT '短信内容',
    `variables`  varchar(200) NOT NULL DEFAULT '' COMMENT '模板变量',
    `status`     tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态:0=禁用,1=启用',
    `updatetime` int(10) unsigned DEFAULT NULL COMMENT '更新时间',
    `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='短信模板表';

BEGIN;
INSERT INTO `me_sms_template` VALUES ('1', '用户注册', 'user_register', '', '', '', '1', '1664349210', '1664260457');
INSERT INTO `me_sms_template` VALUES ('2', '用户身份验证', 'user_mobile_verify', '', '', '', '1', '1664348583', '1664296092');
INSERT INTO `me_sms_template` VALUES ('3', '用户验证新手机号', 'user_change_mobile', '', '', '', '1', '1664296339', '1664296212');
INSERT INTO `me_sms_template` VALUES ('4', '用户找回密码', 'user_retrieve_pwd', '', '', '', '1', '1664296333', '1664296300');
COMMIT;

CREATE TABLE `me_sms_variable` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `title` varchar(100) NOT NULL DEFAULT '' COMMENT '标题',
    `name` varchar(50) NOT NULL DEFAULT '' COMMENT '变量名称',
    `value_source` enum('literal','func','sql') NOT NULL DEFAULT 'literal' COMMENT '变量值来源:literal=字面量,func=方法返回值,sql=sql查询结果',
    `value` varchar(200) NOT NULL DEFAULT '' COMMENT '变量值',
    `sql` varchar(500) NOT NULL DEFAULT '' COMMENT 'SQL语句',
    `namespace` varchar(200) NOT NULL DEFAULT '' COMMENT '命名空间',
    `class` varchar(100) NOT NULL DEFAULT '' COMMENT '类名',
    `func` varchar(100) NOT NULL DEFAULT '' COMMENT '方法名',
    `param` varchar(100) NOT NULL DEFAULT '' COMMENT '传递的参数',
    `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态:0=禁用,1=启用',
    `updatetime` int(10) unsigned DEFAULT NULL COMMENT '更新时间',
    `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='模板变量表';
");
        $sms_data = [
            [
                'class' => 'Helper',
                'func' => 'alnum',
                'name' => 'alnum',
                'namespace' => 'modules\\sms\\library',
                'param' => '4',
                'sql' => '',
                'status' => '1',
                'title' => '随机字符-4位',
                'value' => '',
                'value_source' => 'func',
            ],
            [
                'class' => 'Helper',
                'func' => 'numeric',
                'name' => 'code',
                'namespace' => 'modules\\sms\\library',
                'param' => '6',
                'sql' => '',
                'status' => '1',
                'title' => '随机数字-6位',
                'value' => '',
                'value_source' => 'func',
            ],
            [
                'class' => '',
                'func' => '',
                'name' => 'user_count',
                'namespace' => '',
                'param' => '6',
                'sql' => 'SELECT count(id) FROM me_user',
                'status' => '1',
                'title' => '系统会员数量',
                'value' => '',
                'value_source' => 'sql',
            ]
        ];
        $var_model = new \app\admin\model\sms\Variable();
        $var_model->saveAll($sms_data);
        $this->execute("CREATE TABLE `me_oauth_log`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '会员',
  `source` enum('qq','wechat_scan','wechat_mp') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'qq' COMMENT '来源:qq=腾讯QQ,wechat_scan=微信扫码,wechat_mp=微信公众号',
  `uuid` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '三方平台身份标识',
  `extend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '扩展数据',
  `create_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '三方授权登录记录表' ROW_FORMAT = Dynamic;
");


        try {
            $this->execute("ALTER TABLE `me_user_money_log` 
MODIFY COLUMN `type` int(1) NOT NULL DEFAULT 1 COMMENT '用户余额变动类型\r\n1：后台充值\r\n2：用户充值\r\n3：用户购买套餐 4:卡密充值' AFTER `memo`");
            $this->execute("ALTER TABLE `me_user` 
DROP COLUMN `is_vip`;");
            $this->execute("ALTER TABLE `me_user_basic` 
ADD COLUMN `diy_order_prefix` varchar(50) NOT NULL DEFAULT '' COMMENT '自定义订单前缀' AFTER `private_key`");
        }catch (Exception $e){
            dump($e->getMessage());
        }

        $login_method = \app\admin\model\Config::where('name','login_method')->find();
        $login_method->type = 'selects';
        $login_method->value=["username","email"];
        $login_method->content=json_encode([
            'username'=>'用户名',
            'email'=>'邮箱',
            'mobile'=>'手机号',
        ]);
        $login_method->save();

        $config_data = [
            [
                'name'      => 'rechange_channel',
                'group'     => 'pay_config',
                'title'     => '充值支付通道',
                'type'      => 'select',
                'value'     => 'pc',
                'content'   => "pc=官方\r\nypay=易支付",
                'rule'      => 'required',
                'allow_del' => 1,
                'weigh'     => 99,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'ypay_pid',
                'group'     => 'pay_config',
                'title'     => '易支付PID',
                'type'      => 'string',
                'value'     => '',
                'content'   => "",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'ypay_secret',
                'group'     => 'pay_config',
                'title'     => '易支付密钥',
                'type'      => 'string',
                'value'     => '',
                'content'   => "",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'ypay_submit',
                'group'     => 'pay_config',
                'title'     => '易支付密钥',
                'type'      => 'string',
                'value'     => '',
                'content'   => "",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'captcha_config',
                'group'     => 'login_config',
                'title'     => '登录/注册验证码',
                'type'      => 'select',
                'value'     => 'image',
                'content'   => "close=关闭\r\nimage=图片验证码\r\ngeetest=极验",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'login_background_method',
                'group'     => 'login_config',
                'title'     => '登录/注册背景设置',
                'type'      => 'select',
                'value'     => 'default',
                'content'   => "default=默认\r\nupload=本地图片\r\napi=API",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'login_background_upload',
                'group'     => 'login_config',
                'title'     => '登录/注册页面背景图片',
                'tip'     => '上传图片',
                'type'      => 'image',
                'value'     => '',
                'content'   => "",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'login_background_api',
                'group'     => 'login_config',
                'title'     => '登录/注册背景图片API地址',
                'type'      => 'string',
                'value'     => '',
                'content'   => "",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'geetest_id',
                'group'     => 'login_config',
                'title'     => '极验ID',
                'type'      => 'string',
                'value'     => '',
                'content'   => "",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'geetest_key',
                'group'     => 'login_config',
                'title'     => '极验KEY',
                'type'      => 'string',
                'value'     => '',
                'content'   => "",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
            [
                'name'      => 'geetest_url',
                'group'     => 'login_config',
                'title'     => '极验URL',
                'tip' =>'填写当前站点UTL  不带http 和结尾不带/',
                'type'      => 'string',
                'value'     => '',
                'content'   => "",
                'rule'      => '',
                'allow_del' => 1,
                'weigh'     => 0,
                'extend'     => '',
                'inputExtend'     => '',
            ],
        ];
        (new \app\admin\model\Config())->saveAll($config_data);


        $config = \app\admin\model\Config::where('name','version')->find();
        if (!empty($config)){
            $config->value = 'V1.0.5';
            $config->save();
        }
        
        $this->execute("INSERT INTO `me_admin_rule`( `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES ( 160, 'menu', '卡密管理', 'card', 'card', 'el-icon-Postcard', 'tab', '', '/src/views/backend/card/index.vue', 1, 'none', '', 0, '1', 1714164099, 1713946430);
INSERT INTO `me_admin_rule`( `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (174, 'button', '查看', 'card/index', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1713946430, 1713946430);
INSERT INTO `me_admin_rule`( `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (174, 'button', '添加', 'card/add', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1713946430, 1713946430);
INSERT INTO `me_admin_rule`( `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (174, 'button', '编辑', 'card/edit', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1713946430, 1713946430);
INSERT INTO `me_admin_rule`( `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (174, 'button', '删除', 'card/del', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1713946430, 1713946430);
INSERT INTO `me_admin_rule`( `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `keepalive`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (174, 'button', '快速排序', 'card/sortable', '', '', NULL, '', '', 0, 'none', '', 0, '1', 1713946430, 1713946430);
");
        $this->execute("CREATE TABLE `me_card`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `key` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '卡号',
  `price` int(10) NOT NULL DEFAULT 0 COMMENT '金额',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '状态:0=未使用,1=已使用',
  `expiration_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '截止时间',
  `use_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '使用时间',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '用户ID',
  `create_time` bigint(16) UNSIGNED NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '卡密表' ROW_FORMAT = Dynamic;
");

        $menu = [
            [
                'type'      => 'menu_dir',
                'title'     => '短信管理',
                'pid'       => '44',
                'name'      => 'sms',
                'path'      => 'sms',
                'icon'      => 'el-icon-ChatLineRound',
                'menu_type' => 'tab',
                'children'  => [
                    [
                        'type'      => 'menu',
                        'title'     => '短信配置',
                        'name'      => 'sms/config',
                        'path'      => 'sms/config',
                        'icon'      => 'el-icon-Setting',
                        'menu_type' => 'tab',
                        'component' => '/src/views/backend/sms/config.vue',
                        'keepalive' => '1',
                        'children'  => [
                            ['type' => 'button', 'title' => '查看', 'name' => 'sms/config/getConfigKey'],
                            ['type' => 'button', 'title' => '修改配置', 'name' => 'sms/config/saveConfig'],
                        ]
                    ],
                    [
                        'type'      => 'menu',
                        'title'     => '模板变量管理',
                        'name'      => 'sms/variable',
                        'path'      => 'sms/variable',
                        'icon'      => 'fa fa-asterisk',
                        'menu_type' => 'tab',
                        'component' => '/src/views/backend/sms/variable/index.vue',
                        'keepalive' => '1',
                        'children'  => [
                            ['type' => 'button', 'title' => '查看', 'name' => 'sms/variable/index'],
                            ['type' => 'button', 'title' => '添加', 'name' => 'sms/variable/add'],
                            ['type' => 'button', 'title' => '编辑', 'name' => 'sms/variable/edit'],
                            ['type' => 'button', 'title' => '删除', 'name' => 'sms/variable/del'],
                        ]
                    ],
                    [
                        'type'      => 'menu',
                        'title'     => '短信模板管理',
                        'name'      => 'sms/template',
                        'path'      => 'sms/template',
                        'icon'      => 'el-icon-Document',
                        'menu_type' => 'tab',
                        'component' => '/src/views/backend/sms/template/index.vue',
                        'keepalive' => '1',
                        'remark'    => '不同服务商可能需要不同的模板ID，所以单个模板并不一定适用于所有服务商，若有轮询服务商发送的需求，多数情况需自行通过代码实现',
                        'children'  => [
                            ['type' => 'button', 'title' => '查看', 'name' => 'sms/template/index'],
                            ['type' => 'button', 'title' => '添加', 'name' => 'sms/template/add'],
                            ['type' => 'button', 'title' => '编辑', 'name' => 'sms/template/edit'],
                            ['type' => 'button', 'title' => '删除', 'name' => 'sms/template/del'],
                        ]
                    ]
                ]
            ]
        ];
        Menu::create($menu);
        $menu = [];
        $menu = [
            [
                'type'      => 'menu_dir',
                'title'     => '第三方授权登录',
                'pid'       => '44',
                'name'      => 'oauth',
                'path'      => 'oauth',
                'icon'      => 'fa fa-handshake-o',
                'menu_type' => null,
                'children'  => [
                    [
                        'type'      => 'menu',
                        'title'     => '三方平台配置',
                        'name'      => 'oauth/config',
                        'path'      => 'oauth/config',
                        'icon'      => 'fa fa-gear',
                        'menu_type' => 'tab',
                        'component' => '/src/views/backend/oauth/config/index.vue',
                        'keepalive' => '1',
                        'children'  => [
                            ['type' => 'button', 'title' => '查看', 'name' => 'oauth/config/index'],
                            ['type' => 'button', 'title' => '修改配置', 'name' => 'oauth/config/saveConfig'],
                        ]
                    ],
                    [
                        'type'      => 'menu',
                        'title'     => '授权登录记录',
                        'name'      => 'oauth/log',
                        'path'      => 'oauth/log',
                        'icon'      => 'fa fa-list-alt',
                        'menu_type' => 'tab',
                        'component' => '/src/views/backend/oauth/log/index.vue',
                        'keepalive' => '1',
                        'children'  => [
                            ['type' => 'button', 'title' => '查看', 'name' => 'oauth/log/index'],
                            ['type' => 'button', 'title' => '添加', 'name' => 'oauth/log/add'],
                            ['type' => 'button', 'title' => '编辑', 'name' => 'oauth/log/edit'],
                            ['type' => 'button', 'title' => '删除', 'name' => 'oauth/log/del'],
                        ]
                    ],
                ],
            ]
        ];
        Menu::create($menu);
        \app\admin\model\AdminRule::where([
            'name' => 'mail',
            'pid'  => 0
        ])->update(['pid'=>44]);
        $this->execute("DELETE FROM `me_user_rule`;");
        $this->execute("INSERT INTO `me_user_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `no_login_valid`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (9, 0, 'route', '仪表盘', 'dashboards-analytics', 'dashboards-analytics', 'fa fa-circle-o', 'tab', '', '', 0, 'none', '', 16, '1', 1714406506, 1714222152);
INSERT INTO `me_user_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `no_login_valid`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (10, 0, 'route', '账户设置', 'apps-user-list-index-set', 'apps-user-list', 'fa fa-circle-o', 'tab', '', '', 0, 'none', '', 13, '1', 1714406854, 1714406166);
INSERT INTO `me_user_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `no_login_valid`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (11, 0, 'route', '在线充值', 'apps-system-online-recharge', 'apps-system-online-recharge', 'fa fa-circle-o', 'tab', '', '', 0, 'none', '', 12, '1', 1714406550, 1714406193);
INSERT INTO `me_user_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `no_login_valid`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (12, 0, 'route', '套餐购买', 'pages-pricing', 'pages-pricing', 'fa fa-circle-o', 'tab', '', '', 0, 'none', '', 11, '1', 1714406550, 1714406219);
INSERT INTO `me_user_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `no_login_valid`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (13, 0, 'route', '通道管理', 'tabler-settings-bolt', '', 'fa fa-circle-o', 'tab', '', '', 0, 'none', '', 10, '1', 1714406559, 1714406265);
INSERT INTO `me_user_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `no_login_valid`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (14, 13, 'route', '通道列表', 'apps-system-channel-channel-list', 'apps-system-channel-channel-list', 'fa fa-circle-o', 'tab', '', '', 0, 'none', '', 14, '1', 1714406292, 1714406292);
INSERT INTO `me_user_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `no_login_valid`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (15, 13, 'route', '通道配置', 'apps-system-channel-channel-list', 'apps-system-channel-channel-set', 'fa fa-circle-o', 'tab', '', '', 0, 'none', '', 15, '1', 1714406336, 1714406336);
INSERT INTO `me_user_rule`(`id`, `pid`, `type`, `title`, `name`, `path`, `icon`, `menu_type`, `url`, `component`, `no_login_valid`, `extend`, `remark`, `weigh`, `status`, `update_time`, `create_time`) VALUES (16, 0, 'route', '订单记录', 'apps-system-older-list', 'apps-system-older-list', 'fa fa-circle-o', 'tab', '', '', 0, 'none', '', 9, '1', 1714406559, 1714406357);
");
        $this->execute("INSERT INTO `me_mail_template`(`id`, `name`, `title`, `content`, `status`, `remark`, `update_time`, `create_time`) VALUES (2, 'login', '登录', 'Ypay登录验证码：{code}', 1, '', 1714148816, 1714148816);
INSERT INTO `me_mail_template`(`id`, `name`, `title`, `content`, `status`, `remark`, `update_time`, `create_time`) VALUES (3, 'register', '注册', 'Ypay注册验证码：{code}', 1, '', 1714148816, 1714148816);
");
    }
}
