<?php

namespace geetest;


use App\Http\Controllers\Controller;
use think\facade\Cache;



class CheckGeetestStatus
{
    const HTTP_TIMEOUT_DEFAULT = 5; // 单位：秒
    const BYPASS_URL = "https://bypass.geetest.com/v1/bypass_status.php";
    const GEETEST_STATUS_KEY = "Cache_CHECK_GEETEST_STATUS_KEY";

    /**
     * 发送GET请求，获取服务器返回结果
     */
    private function httpGet($url, $params)
    {
        $url .= "?" . http_build_query($params);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::HTTP_TIMEOUT_DEFAULT); // 设置连接主机超时（单位：秒）
        curl_setopt($ch, CURLOPT_TIMEOUT, self::HTTP_TIMEOUT_DEFAULT); // 允许 cURL 函数执行的最长秒数（单位：秒）
        //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        //curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res;
    }

    /**
     * 请求极验 bypass 接口, 将极验云服务状态记录到 Cache 中
     */
    public function checkStatus()
    {
        $geetest_config = get_sys_config('','login_config');
        $url = self::BYPASS_URL;
        $params = array("gt" => $geetest_config['geetest_id']);
        try {
            $resBody = $this->httpGet($url, $params);

            $res_array = json_decode($resBody, true);
            $status = $res_array["status"];
        } catch (\Exception $e) {
            $status = "fail";
        }
        if($status != null && $status != ""){
            Cache::set(self::GEETEST_STATUS_KEY, $status);
        }else{
            Cache::set(self::GEETEST_STATUS_KEY, "fail");
        }
    }

    /**
     * 获取 Cache 中的极验云服务状态
     */
    public static function getGeetestStatus()
    {
        $status = Cache::get(self::GEETEST_STATUS_KEY);
        if(!empty($status) && strcmp($status,"success")==0){
            return true;
        }else{
            return false;
        }
    }
}