<?php

define("GEETEST_ID", "a86fb2a4ea47ad8ab8088aac302ebd68");
define("GEETEST_KEY", "5437c501b7bdcbfefaf061f80edccae8");
