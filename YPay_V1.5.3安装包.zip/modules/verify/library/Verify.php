<?php

namespace modules\verify\library;

use app\common\library\Email;
use ba\Captcha;
use PHPMailer\PHPMailer\Exception;
use think\facade\Cache;
use think\facade\Db;

class Verify
{
    /**
     * 生成验证码
     * @param int    $type
     * @param string $captchaId
     * @param string $toMail
     */
    public static function create(int $type, string $captchaId, string $toMail = '')
    {
        $result = '';
        $config = self::getConfig($type);
        switch ($type) {
            case 1:
                //图片
                $obj    = new Captcha($config);
                $result = $obj->entry($captchaId);
                break;
            case 2:
                //文本
                $obj    = new Captcha($config);
                $result = $obj->create($captchaId);
                break;
            case 3:
                //计算
                $result = Calculate::create($captchaId);
                break;
            case 4:
                //邮箱
                $mail = new Email();
                if ($mail->configured) {
                    $obj    = new Captcha($config);
                    $result = $obj->create($captchaId);
                    $body   = '验证码：' . $result;
                    try {
                        $mail->isSMTP();
                        $mail->addAddress($toMail);
                        $mail->isHTML();
                        $mail->setSubject('安全验证');
                        $mail->Body = $body;
                        $mail->send();
                    } catch (Exception) {
                        //var_dump($mail->ErrorInfo);
                        throw new \Exception($mail->ErrorInfo);
                    }
                } else {
                    throw new \Exception("请先完善邮箱配置");
                }
                break;
        }
        return $result;
    }

    /**
     * 验证验证码
     * @param int    $type
     * @param string $captchaId
     * @param string $captcha
     * @return bool
     */
    public static function check(int $type, string $captchaId, string $captcha): bool
    {
        $result = true;
        switch ($type) {
            case 1:
                //图形验证
            case 2:
                //文本输入验证
            case 4:
                //邮箱验证
                $config = array(
                    'reset' => false //验证成功后是否删除
                );
                $obj    = new Captcha($config);
                if (!$obj->check($captcha, $captchaId)) {
                    $result = false;
                }
                break;
            case 3:
                //计算
                $result = Calculate::check($captcha, $captchaId);
                break;
        }
        return $result;
    }

    /**
     * 获取配置
     * @param int $type
     * @return array
     */
    public static function getConfig(int $type): array
    {
        $result = [];
        switch ($type) {
            case 1:
                //图形验证
                $key    = 'verify-modules-captcha';
                $result = Cache::get($key);
                if (!$result) {
                    $row = Db::name('verify_config')
                        ->where('key', '=', 'captcha')
                        ->withAttr('val', function ($v) {
                            return json_decode($v, true);
                        })
                        ->field('val')
                        ->find();

                    $result = [
                        'codeSet'  => $row['val']['codeSet'],
                        'useCurve' => $row['val']['useCurve'] == 1 ? true : false,
                        'useNoise' => $row['val']['useNoise'] == 1 ? true : false,
                        'bg'       => self::rgbaStringToArray($row['val']['bg']),
                        'length'   => $row['val']['length'],
                        'expire'   => bcmul($row['val']['expiry'], 60),
                        'reset'    => false,
                        'fontSize' => $row['val']['size'],
                    ];
                    Cache::tag('verify-modules')->set($key, $result);
                }
                break;
            case 2:
                //文本输入验证
                $key    = 'verify-modules-text';
                $result = Cache::get($key);
                if (!$result) {
                    $row = Db::name('verify_config')
                        ->where('key', '=', 'text')
                        ->withAttr('val', function ($v) {
                            return json_decode($v, true);
                        })
                        ->field('val')
                        ->find();

                    $result = [
                        'zhSet'  => $row['val']['codeSet'],
                        'length' => $row['val']['length'],
                        'useZh'  => true,
                        'expire' => bcmul($row['val']['expiry'], 60),
                        'reset'  => false
                    ];
                    Cache::tag('verify-modules')->set($key, $result);
                }
                break;
            case 3:
                //计算
                $key    = 'verify-modules-calculate';
                $result = Cache::get($key);
                if (!$result) {
                    $row = Db::name('verify_config')
                        ->where('key', '=', 'calculate')
                        ->withAttr('val', function ($v) {
                            return json_decode($v, true);
                        })
                        ->field('val')
                        ->find();

                    $result = [
                        'data'   => $row['val']['data'],
                        'spec'   => $row['val']['spec'],
                        'expire' => bcmul($row['val']['expiry'], 60)
                    ];
                    Cache::tag('verify-modules')->set($key, $result);
                }
                break;
            case 4:
                //邮箱验证
                $key    = 'verify-modules-mail';
                $result = Cache::get($key);
                if (!$result) {
                    $row = Db::name('verify_config')
                        ->where('key', '=', 'mail')
                        ->withAttr('val', function ($v) {
                            return json_decode($v, true);
                        })
                        ->field('val')
                        ->find();

                    $result = [
                        'codeSet' => $row['val']['codeSet'],
                        'length'  => $row['val']['length'],
                        'expire'  => bcmul($row['val']['expiry'], 60),
                        'reset'   => false
                    ];
                    Cache::tag('verify-modules')->set($key, $result);
                }
                break;

        }
        return $result;
    }

    /**
     * rgb字符串转数组
     * @param string $colorStr
     * @return array
     */
    public static function rgbaStringToArray(string $colorStr): array
    {
        // 正则表达式匹配rgba格式的颜色字符串
        preg_match('/rgba\((\d+),\s*(\d+),\s*(\d+),\s*(\d*\.?\d+)\)/', $colorStr, $matches);
        if (count($matches) < 5) {
            // 如果匹配不成功
            return [255, 255, 255];
        }
        // 移除第一个元素（完整匹配的字符串），保留实际的数值
        array_shift($matches);
        // 转换匹配到的字符串为相应的整数或浮点数
        $result = array_map(function ($value) {
            return strpos($value, '.') !== false ? floatval($value) : intval($value);
        }, $matches);
        return $result;
    }
}