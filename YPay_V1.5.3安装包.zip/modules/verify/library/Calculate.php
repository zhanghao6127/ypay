<?php

namespace modules\verify\library;

use think\facade\Db;

class Calculate
{
    public static string $seKey = 'verify';

    /**
     * 删除过期的验证码
     */
    public static function del(): bool
    {
        // 清理过期的验证码
        Db::name('captcha')
            ->where('expire_time', '<', time())
            ->delete();

        return true;
    }

    /**
     * 创建验证计算公式
     * @param string $id 验证码标识
     * @return string
     */
    public static function create(string $id): string
    {
        self::del();
        $captcha = $question = '';
        $config  = Verify::getConfig(3);
        $expire  = $config['expire'];
        $data    = intval($config['data']);
        while (true) {
            $num1      = rand(1, $data);
            $num2      = rand(1, $data);
            $operators = $config['spec'];
            $operator  = $operators[array_rand($operators)];
            if ($operator == '/') {
                // 确保除法结果为正整数
                while ($num1 % $num2 != 0 || $num1 < $num2) {
                    $num1 = rand(1, $data);
                    $num2 = rand(1, $data);
                }
                $captcha = intval($num1 / $num2);
            } else {
                switch ($operator) {
                    case '+':
                        $captcha = $num1 + $num2;
                        break;
                    case '-':
                        // 确保减法结果为正整数，即$num1 > $num2
                        if ($num1 <= $num2) {
                            // 交换num1和num2的位置或重新生成，确保$num1大于$num2
                            list($num1, $num2) = [max($num1, $num2), min($num1, $num2)];
                        }
                        $captcha = $num1 - $num2;
                        break;
                    case '*':
                        $captcha = $num1 * $num2;
                        break;
                }
            }

            $question = "$num1 $operator $num2 = ?";
            // 问题生成后退出循环
            break;
        }

        $nowTime     = time();
        $key         = self::authCode(self::$seKey, $id);
        $captchaTemp = Db::name('captcha')->where('key', $key)->find();
        if ($captchaTemp) {
            // 重复的为同一标识创建验证码
            Db::name('captcha')->where('key', $key)->delete();
        }
        $code = self::authCode($captcha, $id);
        Db::name('captcha')
            ->insert([
                'key'         => $key,
                'code'        => $code,
                'captcha'     => $captcha,
                'create_time' => $nowTime,
                'expire_time' => $nowTime + $expire
            ]);

        return $question;
    }

    /**
     * 验证验证码是否正确
     * @param string $code 用户验证码
     * @param string $id   验证码标识
     * @return bool 验证码是否正确
     */
    public static function check(string $code, string $id): bool
    {
        self::del();
        $key    = self::authCode(self::$seKey, $id);
        $seCode = Db::name('captcha')->where('key', $key)->find();
        // 验证码为空
        if (empty($code) || empty($seCode)) {
            return false;
        }
        // 验证码过期
        if (time() > $seCode['expire_time']) {
            Db::name('captcha')->where('key', $key)->delete();
            return false;
        }
        if (self::authCode(strtoupper($code), $id) == $seCode['code']) {
            return true;
        }
        return false;
    }

    /**
     * 加密验证码
     * @param string $str 验证码字符串
     * @param string $id  验证码标识
     */
    public static function authCode(string $str, string $id): string
    {
        $key = substr(md5(self::$seKey), 5, 8);
        $str = substr(md5($str), 8, 10);
        return md5($key . $str . $id);
    }
}