<?php

namespace modules\nuxtoauth;

use Throwable;
use think\facade\Cache;
use app\common\library\Menu;
use app\common\model\Config;

class Nuxtoauth
{
    /**
     * 安装
     * @throws Throwable
     */
    public function install(): void
    {
        $menu = [
            [
                'type'      => 'menu_dir',
                'title'     => '第三方授权登录',
                'name'      => 'oauth',
                'path'      => 'oauth',
                'icon'      => 'fa fa-handshake-o',
                'menu_type' => null,
                'children'  => [
                    [
                        'type'      => 'menu',
                        'title'     => '三方平台配置',
                        'name'      => 'oauth/config',
                        'path'      => 'oauth/config',
                        'icon'      => 'fa fa-gear',
                        'menu_type' => 'tab',
                        'component' => '/src/views/backend/oauth/config/index.vue',
                        'keepalive' => '1',
                        'children'  => [
                            ['type' => 'button', 'title' => '查看', 'name' => 'oauth/config/index'],
                            ['type' => 'button', 'title' => '修改配置', 'name' => 'oauth/config/saveConfig'],
                        ]
                    ],
                    [
                        'type'      => 'menu',
                        'title'     => '授权登录记录',
                        'name'      => 'oauth/log',
                        'path'      => 'oauth/log',
                        'icon'      => 'fa fa-list-alt',
                        'menu_type' => 'tab',
                        'component' => '/src/views/backend/oauth/log/index.vue',
                        'keepalive' => '1',
                        'children'  => [
                            ['type' => 'button', 'title' => '查看', 'name' => 'oauth/log/index'],
                            ['type' => 'button', 'title' => '添加', 'name' => 'oauth/log/add'],
                            ['type' => 'button', 'title' => '编辑', 'name' => 'oauth/log/edit'],
                            ['type' => 'button', 'title' => '删除', 'name' => 'oauth/log/del'],
                        ]
                    ],
                ],
            ]
        ];
        Menu::create($menu);
    }

    /**
     * 卸载
     * @throws Throwable
     */
    public function uninstall(): void
    {
        Menu::delete('oauth', true);
    }

    /**
     * 启用
     * @throws Throwable
     */
    public function enable(): void
    {
        Menu::enable('oauth');
        Config::addQuickEntrance('第三方登录鉴权配置', 'oauth/config');

        // 恢复配置
        $config = Cache::pull('oauth-module-config');
        if ($config) {
            @file_put_contents(config_path() . 'oauth.php', $config);
        }
    }

    /**
     * 禁用
     * @throws Throwable
     */
    public function disable(): void
    {
        Menu::disable('oauth');
        Config::removeQuickEntrance('第三方登录鉴权配置');

        // 备份配置
        $config = @file_get_contents(config_path() . 'oauth.php');
        if ($config) {
            Cache::set('oauth-module-config', $config, 3600);
        }
    }
}