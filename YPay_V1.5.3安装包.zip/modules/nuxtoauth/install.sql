CREATE TABLE IF NOT EXISTS `__PREFIX__oauth_log` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员',
    `source` enum('qq','wechat_scan','wechat_mp') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'qq' COMMENT '来源:qq=腾讯QQ,wechat_scan=微信扫码,wechat_mp=微信公众号',
    `uuid` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '三方平台身份标识',
    `extend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '扩展数据',
    `create_time` bigint(16) unsigned DEFAULT NULL COMMENT '创建时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='三方授权登录记录表';